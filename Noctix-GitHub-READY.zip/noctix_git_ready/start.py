"""Reliable production launcher for Noctix."""
from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BOT_DIR = ROOT / "bot"

if not BOT_DIR.is_dir():
    raise SystemExit("VeX startup error: the 'bot' directory is missing.")

sys.path.insert(0, str(BOT_DIR))

# python-dotenv is optional at runtime. Hosting panels normally provide
# environment variables directly, so its absence must never crash VeX.
try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = None

if load_dotenv is not None:
    load_dotenv(ROOT / ".env")
    load_dotenv(BOT_DIR / ".env", override=False)

os.chdir(BOT_DIR)

TOKEN = os.getenv("TOKEN", "").strip()


async def main() -> None:
    # Synchronize application emojis before importing any cog.  This prevents
    # stale :0 IDs from being captured by `from utils.emoji import ...`.
    try:
        from utils.sync_emojis import startup_sync
        await startup_sync(TOKEN)
    except Exception as exc:
        # Emoji problems must never prevent the bot itself from starting.
        print(f"[Noctix] Emoji startup check skipped: {type(exc).__name__}: {exc}")

    from VeXCore import main as bot_main
    await bot_main()


if __name__ == "__main__":
    asyncio.run(main())
