/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║                                                                  ║
 * ║   ░█▀▀░█▀█░█▀▄░█▀▀░█░█   ░█▀▄░█▀▀░█░█░█▀▀                     ║
 * ║   ░█░░░█░█░█░█░█▀▀░▄▀▄   ░█░█░█▀▀░▀▄▀░▀▀█                     ║
 * ║   ░▀▀▀░▀▀▀░▀▀░░▀▀▀░▀░▀   ░▀▀░░▀▀▀░░▀░░▀▀▀                     ║
 * ║                                                                  ║
 * ║           © 2026 Noctix Team — All Rights Reserved               ║
 * ║                                                                  ║
 * ║   discord  ──  https://discord.gg/mGfq3fK3pD                      ║
 * ║   youtube  ──  https://youtube.com/@Noctix Team                   ║
 * ║   github   ──  https://github.com/NoctixTeam                        ║
 * ║                                                                  ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

import React from "react";
import { cn } from "@/lib/utils";

interface PageHeaderProps {
  title: string;
  description?: string;
  children?: React.ReactNode;
  icon?: React.ElementType;
  className?: string;
}

export const PageHeader = ({ 
  title, 
  description, 
  children, 
  icon: Icon,
  className 
}: PageHeaderProps) => {
  return (
    <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8", className)}>
      <div>
        <h1 className="text-3xl font-black text-white flex items-center gap-3 tracking-tight">
          {Icon && <Icon className="h-8 w-8 text-primary shrink-0" />}
          {title}
        </h1>
        {description && (
          <p className="text-slate-400 mt-1 font-medium italic">
            {description}
          </p>
        )}
      </div>
      {children && (
        <div className="flex items-center gap-4">
          {children}
        </div>
      )}
    </div>
  );
};
