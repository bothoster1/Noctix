# Noctix Hosting

## Startup command
Use exactly:

```bash
python3 Noctix.py
```

Do not put `container~ exec` in the startup command; that is a host-internal prefix, not part of the Python command.

## Dependencies
Install the root `requirements.txt` before first start:

```bash
python3 -m pip install -r requirements.txt
```

`python-dotenv` is listed as a dependency but is optional at runtime. Noctix can start using environment variables supplied by the hosting panel even if `python-dotenv` is unavailable.

Required environment variable:

```env
TOKEN=your_bot_token
```

Emoji synchronization remains enabled by default. API/tunnel services remain disabled unless explicitly configured.
