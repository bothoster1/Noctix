"""VeX preflight checker.
Run `python3 preflight.py` before deployment to catch common hosting mistakes.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BOT = ROOT / "bot"

def fail(msg: str) -> None:
    print(f"[FAIL] {msg}")
    raise SystemExit(1)

def main() -> None:
    checks = [
        (ROOT / "VeX.py", "root launcher"),
        (ROOT / "start.py", "startup helper"),
        (BOT / "VeXCore.py", "bot entry"),
        (BOT / "core" / "zyrox.py", "Noctix bot core"),
        (BOT / "cogs" / "__init__.py", "cog loader"),
        (ROOT / "requirements.txt", "requirements"),
    ]
    for path, label in checks:
        if not path.exists():
            fail(f"Missing {label}: {path}")

    token = os.getenv("TOKEN", "").strip()
    if not token:
        print("[WARN] TOKEN is not set in this shell. Hosting environment must provide it.")
    else:
        print("[OK] TOKEN is present.")

    print("[OK] VeX file layout looks valid.")
    print("[OK] Use: python3 VeX.py")

if __name__ == "__main__":
    main()
