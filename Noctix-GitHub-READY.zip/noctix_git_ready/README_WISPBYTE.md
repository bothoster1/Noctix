# Noctix — Wispbyte / Pterodactyl-style Bot Hosting

This build is prepared for Python bot hosts such as Wispbyte and other Pterodactyl-style panels.

## Startup
- Runtime image: **Python 3.11+**
- Startup file/command: `python3 main.py`
- Additional Python packages: **leave empty**
- Required environment variable: `TOKEN` = your Discord bot token
- Optional: `OWNER_IDS=1472042046884679801,1518889511327760537`
- Optional: `BOT_NAME=Noctix`
- Optional: `SUPPORT_SERVER=https://discord.gg/mGfq3fK3pD`
- `API_ENABLED=false`
- `TUNNEL_ENABLED=false`
- `EMOJI_SYNC=true`

Wispbyte supports Python Discord bots and provides a Startup section for the command, packages, and environment variables. Keep the token in the environment-variable section rather than in the uploaded files. citeturn0search3turn0search4

## Upload
Upload the **contents of this project folder** so `main.py` is at the server root. Do not upload `.env` files, database files, `__pycache__`, or compiled `.pyc` files.

## Why `main.py` exists
`main.py` is a simple host entry point that delegates to Noctix's production launcher. The launcher checks the required token, loads dependencies from `requirements.txt`, and then starts the Discord bot.

## Removed
- AI command/event/utilities
- AI-only dependencies
- Games command/module/assets
- Standalone Blackjack and Slots cogs
- Game-only dependencies
- AI/Games entries from the Discord help menu
- AI/Games feature entries from the dashboard

The remaining bot is focused on moderation, antinuke, automod, utility, music, tickets, giveaways, leveling, custom roles, server configuration, developer controls, no-prefix access, and related core features.
