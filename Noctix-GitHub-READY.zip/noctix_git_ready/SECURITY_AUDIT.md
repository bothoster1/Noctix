# Noctix Security Audit — Static Pass

This package received a static hardening pass before release.

## Fixed
- Removed Python `eval()` from the calculator and replaced it with an AST allow-list evaluator.
- Replaced database-backed `eval()` calls in autorole storage with `ast.literal_eval()`.
- Disabled automatic `pip install` execution from application code.
- Made command webhook logging opt-in (`ENABLE_COMMAND_WEBHOOK=false` by default).
- Removed hard-coded stats/log channel IDs; they default to disabled (`0`).
- Kept bot tokens out of source and package files.
- Added owner-only developer diagnostics without shell/eval execution.
- Added per-server configuration storage with atomic JSON replacement.
- Added permission checks to server customization commands.
- Added command cooldowns to new user-facing UI commands.
- Restricted interactive menus to the user who opened them.

## Intentional capabilities
The bot still has the existing moderation, anti-nuke, webhook, voice, and other administrative features from the supplied source. Those are not automatically made safe merely by this audit; Discord permissions should be granted using least privilege.

## Verification
- All Python files parse/compile successfully.
- Emoji manifest references are present for all custom emoji placeholders.
- No bot token is packaged.

A static audit cannot guarantee the absence of every runtime vulnerability. Test the bot in a private test server before production use.
