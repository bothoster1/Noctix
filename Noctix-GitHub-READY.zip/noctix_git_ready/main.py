"""Noctix production launcher for bot hosting panels."""
from __future__ import annotations
import asyncio
from Noctix import main as noctix_main

if __name__ == "__main__":
    asyncio.run(noctix_main())
