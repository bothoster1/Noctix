from __future__ import annotations

import platform
import time
import discord
from discord.ext import commands

from utils.access import (
    is_owner,
    is_owner_or_developer,
    load_developers,
    save_developers,
)
from utils.config import OWNER_IDS
from utils.emoji import (
    SUCCESS, ERROR, INFO, ZSAFE, ZSETTINGS, WARNING,
    VeX_OWNER, VeX_CODE,
)

def owner_or_dev():
    async def predicate(ctx):
        return is_owner_or_developer(ctx.author.id, getattr(ctx.bot, "vex_dev_ids", set()))
    return commands.check(predicate)


def owner_only():
    async def predicate(ctx):
        return is_owner(ctx.author.id)
    return commands.check(predicate)


class VeXDev(commands.Cog):
    """Noctix developer console.

    No shell, eval, arbitrary SQL, file browser, or remote-code execution is
    exposed through chat. Developer membership is owner-controlled.
    """

    def __init__(self, bot):
        self.bot = bot
        self.started = time.monotonic()
        self.bot.vex_dev_ids = load_developers()

    @commands.group(name="dev", invoke_without_command=True, hidden=True)
    @owner_or_dev()
    async def dev(self, ctx):
        await ctx.send(
            f"{VeX_CODE} **Noctix Developer Console**\n"
            f"`{ctx.clean_prefix}dev status` • runtime health\n"
            f"`{ctx.clean_prefix}dev modules` • loaded cogs\n"
            f"`{ctx.clean_prefix}dev intents` • gateway intent state\n"
            f"`{ctx.clean_prefix}dev listdev` • trusted developers\n"
            f"`{ctx.clean_prefix}dev adddev @user` • owner-only developer access\n"
            f"`{ctx.clean_prefix}dev removedev @user` • owner-only removal\n"
            f"`{ctx.clean_prefix}dev addnp @user [duration]` • grant no-prefix\n"
            f"`{ctx.clean_prefix}dev removenp @user` • revoke no-prefix"
        )

    @dev.command(name="status")
    @owner_or_dev()
    async def status(self, ctx):
        e = discord.Embed(title=f"{ZSAFE} Noctix Health", color=0x57F287)
        e.add_field(name="Latency", value=f"{round(self.bot.latency * 1000)} ms")
        e.add_field(name="Guilds", value=str(len(self.bot.guilds)))
        e.add_field(name="Users cached", value=str(len(self.bot.users)))
        e.add_field(name="Python", value=platform.python_version())
        e.add_field(
            name="Uptime",
            value=discord.utils.format_dt(
                discord.utils.utcnow()
                - __import__("datetime").timedelta(seconds=time.monotonic() - self.started),
                "R",
            ),
        )
        e.add_field(name="Developers", value=str(len(self.bot.vex_dev_ids)))
        e.add_field(name="No-prefix grants", value=str(len(getattr(self.bot, "no_prefix_ids", set()))))
        e.set_footer(text="Noctix Developer Console • no remote code execution")
        await ctx.send(embed=e)

    @dev.command(name="modules")
    @owner_or_dev()
    async def modules(self, ctx):
        names = sorted(c.__class__.__name__ for c in self.bot.cogs.values())
        await ctx.send(
            f"{ZSETTINGS} Loaded modules: **{len(names)}**\n"
            + ", ".join(f"`{n}`" for n in names[:100])
        )

    @dev.command(name="intents")
    @owner_or_dev()
    async def intents(self, ctx):
        i = self.bot.intents
        rows = [
            f"`{name}`: **{getattr(i, name)}**"
            for name in (
                "guilds", "members", "messages", "message_content",
                "presences", "reactions", "voice_states",
            )
        ]
        await ctx.send(f"{WARNING} Gateway intents\n" + "\n".join(rows))

    @dev.command(name="listdev")
    @owner_or_dev()
    async def listdev(self, ctx):
        owners = ", ".join(f"<@{x}>" for x in OWNER_IDS) or "None configured"
        devs = ", ".join(f"<@{x}>" for x in sorted(self.bot.vex_dev_ids)) or "None"
        e = discord.Embed(title=f"{VeX_OWNER} VeX Access Control", color=0xFEE75C)
        e.add_field(name="Owners", value=owners, inline=False)
        e.add_field(name="Developers", value=devs, inline=False)
        e.set_footer(text="Only owners can change developer access.")
        await ctx.send(embed=e)

    @dev.command(name="adddev")
    @owner_only()
    async def adddev(self, ctx, user: discord.User):
        if is_owner(user.id):
            return await ctx.send(f"{ERROR} Owners already have full developer access.")
        self.bot.vex_dev_ids.add(user.id)
        save_developers(self.bot.vex_dev_ids)
        await ctx.send(f"{SUCCESS} Added {user.mention} to the **Noctix Developer Team**.")

    @dev.command(name="removedev", aliases=["deldev", "revokedev"])
    @owner_only()
    async def removedev(self, ctx, user: discord.User):
        if user.id not in self.bot.vex_dev_ids:
            return await ctx.send(f"{INFO} {user.mention} is not a configured VeX developer.")
        self.bot.vex_dev_ids.discard(user.id)
        save_developers(self.bot.vex_dev_ids)
        await ctx.send(f"{SUCCESS} Removed {user.mention} from the **Noctix Developer Team**.")

    @dev.command(name="addnp", aliases=["noprefix"])
    @owner_or_dev()
    async def addnp(self, ctx, user: discord.User, duration: str = "lifetime"):
        cog = self.bot.get_cog("NoPrefix")
        if cog is None:
            return await ctx.send(f"{ERROR} The No Prefix module is unavailable.")
        result = await cog.grant(user, duration, ctx.author)
        await ctx.send(result)

    @dev.command(name="removenp")
    @owner_or_dev()
    async def removenp(self, ctx, user: discord.User):
        cog = self.bot.get_cog("NoPrefix")
        if cog is None:
            return await ctx.send(f"{ERROR} The No Prefix module is unavailable.")
        result = await cog.revoke(user, ctx.author)
        await ctx.send(result)


async def setup(bot):
    await bot.add_cog(VeXDev(bot))
