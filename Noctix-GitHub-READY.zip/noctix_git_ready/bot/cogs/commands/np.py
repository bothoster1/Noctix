from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone

import aiosqlite
import discord
from discord.ext import commands, tasks

from utils.access import is_owner_or_developer
from utils.config import OWNER_IDS
from utils.emoji import SUCCESS, ERROR, INFO, TIME, TIMER, ZSAFE, ZSETTINGS, VEX_SETTINGS, LEVEL_UP, VEX_OWNER


DB_PATH = "db/np.db"

DURATIONS = {
    "10m": timedelta(minutes=10),
    "1w": timedelta(weeks=1),
    "3w": timedelta(weeks=3),
    "1m": timedelta(days=30),
    "3m": timedelta(days=90),
    "6m": timedelta(days=180),
    "1y": timedelta(days=365),
    "3y": timedelta(days=365 * 3),
    "lifetime": None,
}


def owner_or_dev():
    async def predicate(ctx):
        return is_owner_or_developer(ctx.author.id, getattr(ctx.bot, "vex_dev_ids", set()))
    return commands.check(predicate)


class NoPrefixSelect(discord.ui.Select):
    def __init__(self, cog, user: discord.User, author: discord.abc.User):
        options = [
            discord.SelectOption(label="10 Minutes", value="10m", emoji=TIME),
            discord.SelectOption(label="1 Week", value="1w", emoji=VEX_SETTINGS),
            discord.SelectOption(label="3 Weeks", value="3w", emoji=VEX_SETTINGS),
            discord.SelectOption(label="1 Month", value="1m", emoji=VEX_SETTINGS),
            discord.SelectOption(label="3 Months", value="3m", emoji=VEX_SETTINGS),
            discord.SelectOption(label="6 Months", value="6m", emoji=VEX_SETTINGS),
            discord.SelectOption(label="1 Year", value="1y", emoji=LEVEL_UP),
            discord.SelectOption(label="3 Years", value="3y", emoji=LEVEL_UP),
            discord.SelectOption(label="Lifetime", value="lifetime", emoji=VEX_OWNER),
        ]
        super().__init__(
            placeholder="Choose a no-prefix duration…",
            min_values=1,
            max_values=1,
            options=options,
        )
        self.cog = cog
        self.user = user
        self.author = author

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author.id:
            return await interaction.response.send_message(
                f"{ERROR} This no-prefix menu belongs to someone else.",
                ephemeral=True,
            )
        result = await self.cog._grant(self.user, self.values[0], self.author)
        await interaction.response.edit_message(
            content=result,
            embed=None,
            view=None,
        )


class NoPrefixView(discord.ui.View):
    def __init__(self, cog, user, author):
        super().__init__(timeout=90)
        self.add_item(NoPrefixSelect(cog, user, author))


class NoPrefix(commands.Cog):
    """Owner/developer controlled no-prefix access.

    Only Noctix owners/developers can manage this system. A granted user can omit
    the configured server prefix until their grant expires.
    """

    def __init__(self, client):
        self.client = client
        self.db_path = DB_PATH
        self.client.no_prefix_ids = set()
        self._initialized = False

    async def _initialize(self):
        await self.setup_database()
        await self._load_active_users()
        self._initialized = True

    async def setup_database(self):
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "CREATE TABLE IF NOT EXISTS np (id INTEGER PRIMARY KEY, expiry_time TEXT NULL)"
            )
            await db.commit()

    async def _load_active_users(self):
        await self._ready.wait() if False else asyncio.sleep(0)
        now = datetime.now(timezone.utc)
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT id, expiry_time FROM np") as cur:
                rows = await cur.fetchall()
            active = set()
            expired = []
            for uid, expiry in rows:
                if not expiry:
                    active.add(int(uid))
                    continue
                try:
                    dt = datetime.fromisoformat(expiry)
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
                    if dt > now:
                        active.add(int(uid))
                    else:
                        expired.append(int(uid))
                except ValueError:
                    expired.append(int(uid))
            if expired:
                await db.executemany("DELETE FROM np WHERE id = ?", [(x,) for x in expired])
                await db.commit()
        self.client.no_prefix_ids = active

    async def cog_load(self):
        await self._initialize()
        self.expiry_check.start()

    def cog_unload(self):
        self.expiry_check.cancel()

    async def _grant(self, user: discord.User, duration: str, author) -> str:
        duration = duration.lower().strip()
        if duration not in DURATIONS:
            return (
                f"{ERROR} Invalid duration `{duration}`. "
                f"Use: `{', '.join(DURATIONS)}`."
            )
        expiry = DURATIONS[duration]
        expiry_dt = None if expiry is None else datetime.now(timezone.utc) + expiry
        expiry_str = expiry_dt.isoformat() if expiry_dt else None

        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "INSERT INTO np (id, expiry_time) VALUES (?, ?) "
                "ON CONFLICT(id) DO UPDATE SET expiry_time=excluded.expiry_time",
                (user.id, expiry_str),
            )
            await db.commit()

        self.client.no_prefix_ids.add(user.id)
        shown = "Lifetime" if expiry_dt is None else f"<t:{int(expiry_dt.timestamp())}:R>"
        return f"{SUCCESS} {user.mention} now has **No Prefix** ({shown})."

    async def grant(self, user: discord.User, duration: str = "lifetime", author=None) -> str:
        return await self._grant(user, duration, author)

    async def revoke(self, user: discord.User, author=None) -> str:
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("DELETE FROM np WHERE id = ?", (user.id,))
            await db.commit()
        self.client.no_prefix_ids.discard(user.id)
        return f"{SUCCESS} Removed No Prefix from {user.mention}."

    @tasks.loop(minutes=5)
    async def expiry_check(self):
        if not self._initialized:
            return
        now = datetime.now(timezone.utc)
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(
                "SELECT id FROM np WHERE expiry_time IS NOT NULL AND expiry_time <= ?",
                (now.isoformat(),),
            ) as cur:
                expired = [int(row[0]) for row in await cur.fetchall()]
            if expired:
                await db.executemany("DELETE FROM np WHERE id = ?", [(x,) for x in expired])
                await db.commit()
        for uid in expired:
            self.client.no_prefix_ids.discard(uid)

    @expiry_check.before_loop
    async def before_expiry_check(self):
        await self.client.wait_until_ready()

    @commands.group(name="np", aliases=["noprefix"], invoke_without_command=True)
    @owner_or_dev()
    async def _np(self, ctx):
        if ctx.invoked_subcommand is None:
            await ctx.send(
                f"{ZSETTINGS} **VeX No Prefix**\n"
                f"`{ctx.clean_prefix}np add @user` • open duration menu\n"
                f"`{ctx.clean_prefix}np remove @user` • revoke\n"
                f"`{ctx.clean_prefix}np list` • list grants\n"
                f"`{ctx.clean_prefix}np status @user` • check access"
            )

    @_np.command(name="add")
    @owner_or_dev()
    async def np_add(self, ctx, user: discord.User):
        if user.id in self.client.no_prefix_ids:
            return await ctx.send(f"{INFO} {user.mention} already has No Prefix.")
        e = discord.Embed(
            title=f"{ZSAFE} Grant No Prefix",
            description=f"Choose how long **{user}** may use VeX without the server prefix.",
            color=0x5865F2,
        )
        e.set_footer(text="Only Noctix owners and developers can manage No Prefix.")
        await ctx.send(embed=e, view=NoPrefixView(self, user, ctx.author))

    @_np.command(name="remove", aliases=["revoke"])
    @owner_or_dev()
    async def np_remove(self, ctx, user: discord.User):
        await ctx.send(await self.revoke(user, ctx.author))

    @_np.command(name="list")
    @owner_or_dev()
    async def np_list(self, ctx):
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT id, expiry_time FROM np ORDER BY id") as cur:
                rows = await cur.fetchall()
        if not rows:
            return await ctx.send(f"{INFO} No No Prefix grants are active.")
        lines = []
        for uid, expiry in rows[:50]:
            target = self.client.get_user(int(uid))
            name = target.mention if target else f"`{uid}`"
            if expiry:
                try:
                    dt = datetime.fromisoformat(expiry)
                    when = f"<t:{int(dt.timestamp())}:R>"
                except ValueError:
                    when = "invalid expiry"
            else:
                when = "Lifetime"
            lines.append(f"{name} — {when}")
        e = discord.Embed(
            title=f"{TIMER} No Prefix Grants • {len(rows)}",
            description="\n".join(lines),
            color=0x5865F2,
        )
        if len(rows) > 50:
            e.set_footer(text=f"Showing 50 of {len(rows)} grants.")
        await ctx.send(embed=e)

    @_np.command(name="status")
    @owner_or_dev()
    async def np_status(self, ctx, user: discord.User):
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT expiry_time FROM np WHERE id = ?", (user.id,)) as cur:
                row = await cur.fetchone()
        if not row:
            return await ctx.send(f"{ERROR} {user.mention} does not have No Prefix.")
        expiry = row[0]
        when = "Lifetime" if not expiry else f"<t:{int(datetime.fromisoformat(expiry).timestamp())}:R>"
        await ctx.send(f"{SUCCESS} {user.mention} has No Prefix • **{when}**")

    @_np.command(name="reset")
    @commands.check(lambda ctx: ctx.author.id in OWNER_IDS)
    async def np_reset(self, ctx):
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("DELETE FROM np")
            await db.commit()
        self.client.no_prefix_ids.clear()
        await ctx.send(f"{SUCCESS} Cleared all No Prefix grants.")


async def setup(bot):
    await bot.add_cog(NoPrefix(bot))
