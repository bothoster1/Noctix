# ╔══════════════════════════════════════════════════════════════════╗
# ║                                                                  ║
# ║   ░█▀▀░█▀█░█▀▄░█▀▀░█░█   ░█▀▄░█▀▀░█░█░█▀▀                     ║
# ║   ░█░░░█░█░█░█░█▀▀░▄▀▄   ░█░█░█▀▀░▀▄▀░▀▀█                     ║
# ║   ░▀▀▀░▀▀▀░▀▀░░▀▀▀░▀░▀   ░▀▀░░▀▀▀░░▀░░▀▀▀                     ║
# ║                                                                  ║
# ║            © 2026 Noctix Team — All Rights Reserved              ║
# ║                                                                  ║
# ║   discord  ──  https://                      ║
# ║   youtube  ──  Noctix Team                   ║
# ║   github   ──  https://github.com/RayExo                        ║
# ║                                                                  ║
# ╚══════════════════════════════════════════════════════════════════╝

from discord.ext import commands
import os
from core import zyrox, Cog
import discord
from utils.emoji import ARROWRED, KING, ZBOT, ZHUMAN, ZROCKET, SUPPORT, TICK
import logging
from discord.ui import View, Button, Select
from utils.config import *

logging.basicConfig(
    level=logging.INFO,
    format="\x1b[38;5;197m[\x1b[0m%(asctime)s\x1b[38;5;197m]\x1b[0m -> \x1b[38;5;197m%(message)s\x1b[0m",
    datefmt="%H:%M:%S",
)

class Guild(Cog):
    def __init__(self, client: zyrox):
        self.client = client
        self.recently_removed_guilds = set()
        self._removal_timestamps = {}

    @commands.Cog.listener(name="on_guild_join")
    async def on_guild_add(self, guild):
        """Send one polished welcome and one owner DM; logging is optional."""
        support_url = serverLink or "https://discord.gg/mGfq3fK3pD"
        try:
            prefix = ">"
            try:
                from utils import getConfig
                cfg = await getConfig(guild.id)
                prefix = cfg.get("prefix", ">")
            except Exception:
                pass

            humans = sum(1 for m in guild.members if not m.bot)
            bots = sum(1 for m in guild.members if m.bot)
            embed = discord.Embed(
                title=f"{TICK} Welcome to {BRAND_NAME}",
                description=(
                    f"**{discord.utils.escape_markdown(guild.name)}** is now protected by **{BRAND_NAME}**.\n\n"
                    f"{ARROWRED} Default prefix: `{prefix}`\n"
                    f"{ARROWRED} Start with `{prefix}help`\n"
                    f"{ARROWRED} Customize the server with `{prefix}custombot`\n\n"
                    f"{SUPPORT} **Need help?** Join the official Noctix support server below."
                ),
                color=0x5865F2,
            )
            embed.add_field(name=f"{ZROCKET} Members", value=f"{len(guild.members):,}", inline=True)
            embed.add_field(name=f"{ZHUMAN} Humans", value=f"{humans:,}", inline=True)
            embed.add_field(name=f"{ZBOT} Bots", value=f"{bots:,}", inline=True)
            embed.set_author(name="Noctix • Secure • Aesthetic", icon_url=self.client.user.display_avatar.url if self.client.user else None)
            if guild.icon:
                embed.set_thumbnail(url=guild.icon.url)
            embed.set_footer(text=f"{BRAND_NAME} • Support • {support_url}")

            view = View(timeout=300)
            view.add_item(Button(label="Support Server", style=discord.ButtonStyle.link, url=support_url))
            view.add_item(Button(label="Noctix Help", style=discord.ButtonStyle.link, url=support_url))

            # Send to a usable channel if possible. Failure here must never stop the DM/log path.
            channel = discord.utils.find(
                lambda c: isinstance(c, discord.TextChannel) and c.permissions_for(guild.me).send_messages,
                guild.text_channels,
            )
            if channel:
                try:
                    await channel.send(embed=embed, view=view)
                except (discord.Forbidden, discord.HTTPException):
                    pass

            # Private owner DM with the same official support link.
            try:
                owner = guild.owner or await self.client.fetch_user(guild.owner_id)
                dm = discord.Embed(
                    title=f"{TICK} Thanks for adding {BRAND_NAME}!",
                    description=(
                        f"Hey **{discord.utils.escape_markdown(owner.display_name)}**! "
                        f"Thanks for bringing **{BRAND_NAME}** into **{discord.utils.escape_markdown(guild.name)}**.\n\n"
                        f"{ZSETTINGS} Use `{prefix}help` to explore the bot.\n"
                        f"{SUPPORT} For setup guides, announcements and support, join our server below."
                    ),
                    color=0x5865F2,
                )
                dm.set_thumbnail(url=self.client.user.display_avatar.url if self.client.user else None)
                dm.set_footer(text="Noctix • Your server, your style, your security")
                dm_view = View(timeout=300)
                dm_view.add_item(Button(label="Join Noctix Support", style=discord.ButtonStyle.link, url=support_url))
                await owner.send(embed=dm, view=dm_view)
            except (discord.Forbidden, discord.HTTPException, AttributeError):
                pass

            # Optional operator log; no configured log channel means no error.
            ch = int(os.getenv("LOG_CHANNEL_ID", "0") or 0)
            if ch:
                log_channel = self.client.get_channel(ch)
                if log_channel:
                    log_embed = discord.Embed(title=f"{TICK} Noctix joined a server", color=0x57F287)
                    log_embed.add_field(name="Server", value=f"{guild.name} (`{guild.id}`)", inline=False)
                    log_embed.add_field(name="Owner", value=f"<@{guild.owner_id}>", inline=True)
                    log_embed.add_field(name="Members", value=f"{len(guild.members):,}", inline=True)
                    await log_channel.send(embed=log_embed)
        except Exception:
            logging.exception("Noctix guild-join handler failed; continuing normally")

    @commands.Cog.listener(name="on_guild_remove")
    async def on_guild_remove(self, guild):
        import time

        current_time = time.time()

        if guild.id in self.recently_removed_guilds:
            last_removal = self._removal_timestamps.get(guild.id, 0)
            if current_time - last_removal < 60:
                return

        self.recently_removed_guilds.add(guild.id)
        self._removal_timestamps[guild.id] = current_time

        if len(self.recently_removed_guilds) > 100:
            self.recently_removed_guilds.clear()

        try:
            ch = int(os.getenv("LOG_CHANNEL_ID", "0") or 0)
            idk = self.client.get_channel(ch)
            if idk is None:
                return

            channels = len(set(self.client.get_all_channels()))
            embed = discord.Embed(title=f"{guild.name}'s Information", color=0xFF0000)

            embed.set_author(name="Guild Removed")
            embed.set_footer(text=f"{guild.name}")

            embed.add_field(
                name="**__About__**",
                value=f"**Name : ** {guild.name}\n**ID :** {guild.id}\n**Owner {KING} :** {guild.owner} (<@{guild.owner_id}>)\n**Created At : **{guild.created_at.month}/{guild.created_at.day}/{guild.created_at.year}\n**Members :** {len(guild.members)}",
                inline=False,
            )
            embed.add_field(
                name="**__Description__**",
                value=f"""{guild.description}""",
                inline=False,
            )

            embed.add_field(
                name="**__Members__**",
                value=f"""
Members : {len(guild.members)}
Humans : {len(list(filter(lambda m: not m.bot, guild.members)))}
Bots : {len(list(filter(lambda m: m.bot, guild.members)))}
                """,
                inline=False,
            )
            embed.add_field(
                name="**__Channels__**",
                value=f"""
Categories : {len(guild.categories)}
Text Channels : {len(guild.text_channels)}
Voice Channels : {len(guild.voice_channels)}
Threads : {len(guild.threads)}
                """,
                inline=False,
            )
            embed.add_field(
                name="__Bot Stats:__",
                value=f"Servers: `{len(self.client.guilds)}`\nUsers: `{len(self.client.users)}`\nChannels: `{channels}`",
                inline=False,
            )

            if guild.icon is not None:
                embed.set_thumbnail(url=guild.icon.url)

            embed.timestamp = discord.utils.utcnow()
            await idk.send(embed=embed)
        except Exception as e:
            logging.error(f"Error in on_guild_remove: {e}")


# client.add_cog(Guild(client))
