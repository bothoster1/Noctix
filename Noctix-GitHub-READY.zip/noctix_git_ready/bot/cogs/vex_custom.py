from __future__ import annotations

from urllib.parse import urlparse

import discord
from discord.ext import commands
from discord.ui import View, Button

from utils.server_profiles import get, reset, update
from utils.config import serverLink
from utils.emoji import (
    INFO, SUCCESS, ERROR, ZSETTINGS, ZSAFE,
    VEX_MENU, VEX_SETTINGS, VEX_COMMUNITY, VEX_SECURITY,
)


def _embed(ctx, title: str, description: str, color: int | None = None):
    cfg = get(ctx.guild.id)
    e = discord.Embed(
        title=f"{VEX_SETTINGS} {title}",
        description=description,
        color=color if color is not None else cfg["color"],
    )
    if cfg.get("icon_url"):
        e.set_thumbnail(url=cfg["icon_url"])
    e.set_footer(text=cfg["footer"])
    return e


def _valid_url(value: str) -> bool:
    try:
        parsed = urlparse(value)
        return parsed.scheme in {"http", "https"} and bool(parsed.netloc)
    except Exception:
        return False


class VeXMenu(View):
    def __init__(self, bot, author_id: int):
        super().__init__(timeout=120)
        self.bot = bot
        self.author_id = author_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(
                f"{ERROR} This menu belongs to <@{self.author_id}>.",
                ephemeral=True,
            )
            return False
        return True

    @discord.ui.button(label="Server Profile", emoji=VEX_SETTINGS, style=discord.ButtonStyle.primary)
    async def server(self, interaction: discord.Interaction, button: Button):
        cfg = get(interaction.guild.id)
        e = discord.Embed(
            title=f"{VEX_SETTINGS} Server Profile",
            color=cfg["color"],
            description=(
                f"**{discord.utils.escape_markdown(cfg['name'])}**\n"
                f"{discord.utils.escape_markdown(cfg['description'])}\n\n"
                f"Accent: `#{cfg['color']:06X}`"
            ),
        )
        if cfg.get("icon_url"):
            e.set_thumbnail(url=cfg["icon_url"])
        e.set_footer(text=cfg["footer"])
        await interaction.response.edit_message(embed=e, view=self)

    @discord.ui.button(label="My Profile", emoji=ZSAFE, style=discord.ButtonStyle.secondary)
    async def me(self, interaction: discord.Interaction, button: Button):
        member = interaction.user
        cfg = get(interaction.guild.id)
        e = discord.Embed(title=f"{ZSAFE} My Profile", color=cfg["color"])
        e.set_author(name=str(member), icon_url=member.display_avatar.url)
        e.add_field(name="Member", value=member.mention)
        e.add_field(name="Account", value=discord.utils.format_dt(member.created_at, "R"))
        if isinstance(member, discord.Member) and member.joined_at:
            e.add_field(name="Joined", value=discord.utils.format_dt(member.joined_at, "R"))
        e.set_thumbnail(url=member.display_avatar.url)
        e.set_footer(text=cfg["footer"])
        await interaction.response.edit_message(embed=e, view=self)

    @discord.ui.button(label="Support", emoji=VEX_COMMUNITY, style=discord.ButtonStyle.secondary)
    async def support(self, interaction: discord.Interaction, button: Button):
        if serverLink:
            await interaction.response.send_message(
                f"{VEX_COMMUNITY} Noctix support: {serverLink}", ephemeral=True
            )
        else:
            await interaction.response.send_message(
                f"{INFO} The Noctix support server has not been configured yet.",
                ephemeral=True,
            )


class VeXCustom(commands.Cog):
    """Per-server Noctix presentation plus safe member profiles.

    Discord does not support a different bot username/avatar per guild through
    the normal bot API. `custombot` therefore customizes Noctix's server-scoped
    embeds and control-panel presentation without attempting an unsupported
    global profile mutation.
    """

    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="noctixmenu", aliases=["menu", "panel"])
    @commands.guild_only()
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def vexmenu(self, ctx):
        cfg = get(ctx.guild.id)
        e = discord.Embed(
            title=f"{VEX_MENU} Noctix Control Center",
            description=(
                f"{VEX_SETTINGS} **Server tools**\n\n"
                f"{INFO} `{ctx.clean_prefix}custombot` — customize VeX for this server\n"
                f"{ZSAFE} `{ctx.clean_prefix}vprofile [member]` — view a member profile\n"
                f"{VEX_SECURITY} **Security & moderation** are available through the main help menu\n"
                f"{VEX_COMMUNITY} Support — join the VeX community"
            ),
            color=cfg["color"],
        )
        if self.bot.user:
            e.set_thumbnail(url=cfg.get("icon_url") or self.bot.user.display_avatar.url)
        e.set_footer(text=cfg["footer"])
        await ctx.send(embed=e, view=VeXMenu(self.bot, ctx.author.id))

    @commands.group(
        name="custombot",
        aliases=["serverprofile", "serverstyle", "noctixconfig"],
        invoke_without_command=True,
    )
    @commands.guild_only()
    async def custombot(self, ctx):
        cfg = get(ctx.guild.id)
        e = _embed(
            ctx,
            "Server Profile",
            (
                f"**Name:** `{discord.utils.escape_markdown(cfg['name'])}`\n"
                f"**Description:** {discord.utils.escape_markdown(cfg['description'])}\n"
                f"**Color:** `#{cfg['color']:06X}`\n"
                f"**Footer:** {discord.utils.escape_markdown(cfg['footer'])}\n"
                f"**Icon:** {'Configured' if cfg.get('icon_url') else 'Default'}\n\n"
                f"Use `{ctx.clean_prefix}custombot help` for customization."
            ),
        )
        await ctx.send(embed=e)

    @custombot.command(name="name")
    @commands.has_guild_permissions(manage_guild=True)
    async def custombot_name(self, ctx, *, value: str):
        value = value.strip()[:32]
        if not value:
            return await ctx.send(
                embed=_embed(ctx, "Invalid name", f"{ERROR} Please provide a non-empty name.", 0xED4245)
            )
        update(ctx.guild.id, name=value)
        await ctx.send(
            embed=_embed(
                ctx, "Profile updated",
                f"{SUCCESS} Server-scoped VeX name is now **{discord.utils.escape_markdown(value)}**.",
            )
        )

    @custombot.command(name="description", aliases=["desc"])
    @commands.has_guild_permissions(manage_guild=True)
    async def custombot_description(self, ctx, *, value: str):
        value = value.strip()[:180]
        if not value:
            return await ctx.send(
                embed=_embed(ctx, "Invalid description", f"{ERROR} Please provide some text.", 0xED4245)
            )
        update(ctx.guild.id, description=value)
        await ctx.send(embed=_embed(ctx, "Profile updated", f"{SUCCESS} Server description updated."))

    @custombot.command(name="color", aliases=["colour"])
    @commands.has_guild_permissions(manage_guild=True)
    async def custombot_color(self, ctx, hex_color: str):
        raw = hex_color.strip().lstrip("#")
        if len(raw) != 6:
            return await ctx.send(
                embed=_embed(ctx, "Invalid color", f"{ERROR} Use a six-digit hex color, e.g. `#5865F2`.", 0xED4245)
            )
        try:
            color = int(raw, 16)
        except ValueError:
            return await ctx.send(
                embed=_embed(ctx, "Invalid color", f"{ERROR} That is not a valid hex color.", 0xED4245)
            )
        update(ctx.guild.id, color=color)
        await ctx.send(embed=_embed(ctx, "Profile updated", f"{SUCCESS} Accent color changed to `#{raw.upper()}`."))

    @custombot.command(name="footer")
    @commands.has_guild_permissions(manage_guild=True)
    async def custombot_footer(self, ctx, *, value: str):
        value = value.strip()[:80]
        if not value:
            return await ctx.send(
                embed=_embed(ctx, "Invalid footer", f"{ERROR} Please provide footer text.", 0xED4245)
            )
        update(ctx.guild.id, footer=value)
        await ctx.send(embed=_embed(ctx, "Profile updated", f"{SUCCESS} Embed footer updated."))

    @custombot.command(name="icon")
    @commands.has_guild_permissions(manage_guild=True)
    async def custombot_icon(self, ctx, url: str | None = None):
        if url is None:
            update(ctx.guild.id, icon_url="")
            return await ctx.send(embed=_embed(ctx, "Icon reset", f"{SUCCESS} Noctix will use the default avatar."))
        if len(url) > 500 or not _valid_url(url):
            return await ctx.send(
                embed=_embed(ctx, "Invalid icon URL", f"{ERROR} Provide a valid `https://` image URL.", 0xED4245)
            )
        update(ctx.guild.id, icon_url=url)
        await ctx.send(embed=_embed(ctx, "Profile updated", f"{SUCCESS} Server icon URL updated."))

    @custombot.command(name="preview")
    async def custombot_preview(self, ctx):
        cfg = get(ctx.guild.id)
        e = _embed(
            ctx,
            cfg["name"],
            cfg["description"],
        )
        e.add_field(name="Customization", value="Name • Description • Color • Footer • Icon")
        await ctx.send(embed=e)

    @custombot.command(name="reset")
    @commands.has_guild_permissions(manage_guild=True)
    async def custombot_reset(self, ctx):
        reset(ctx.guild.id)
        await ctx.send(embed=_embed(ctx, "Profile reset", f"{SUCCESS} Noctix styling has been restored to defaults."))

    @custombot.command(name="help")
    async def custombot_help(self, ctx):
        prefix = ctx.clean_prefix
        text = (
            f"{VEX_SETTINGS} **Noctix Server Customization**\n\n"
            f"`{prefix}custombot name <name>` — server-scoped display name\n"
            f"`{prefix}custombot description <text>` — profile description\n"
            f"`{prefix}custombot color <hex>` — embed accent\n"
            f"`{prefix}custombot footer <text>` — embed footer\n"
            f"`{prefix}custombot icon <url>` — embed thumbnail/avatar URL\n"
            f"`{prefix}custombot icon` — reset the custom icon\n"
            f"`{prefix}custombot preview` — preview the current style\n"
            f"`{prefix}custombot reset` — restore defaults\n\n"
            f"{INFO} Changes require **Manage Server**. These settings affect VeX's "
            f"server-scoped embeds; Discord's actual bot username/avatar remains global."
        )
        await ctx.send(embed=_embed(ctx, "Customization", text))

    @commands.command(name="vprofile", aliases=["userprofile", "memberprofile"])
    @commands.guild_only()
    @commands.cooldown(1, 8, commands.BucketType.user)
    async def profile(self, ctx, member: discord.Member | None = None):
        member = member or ctx.author
        cfg = get(ctx.guild.id)
        e = discord.Embed(title=f"{ZSAFE} User Profile", color=cfg["color"])
        e.set_author(name=str(member), icon_url=member.display_avatar.url)
        e.add_field(name="User", value=member.mention)
        e.add_field(name="Created", value=discord.utils.format_dt(member.created_at, "R"))
        if member.joined_at:
            e.add_field(name="Joined", value=discord.utils.format_dt(member.joined_at, "R"))
        e.set_thumbnail(url=member.display_avatar.url)
        e.set_footer(text=cfg["footer"])
        await ctx.send(embed=e)

    @commands.command(name="noctixinvite", hidden=True)
    @commands.is_owner()
    async def vexinvite(self, ctx):
        await ctx.send(f"👑 Noctix support: {serverLink}")


async def setup(bot):
    await bot.add_cog(VeXCustom(bot))
