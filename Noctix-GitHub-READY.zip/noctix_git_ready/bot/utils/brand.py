from __future__ import annotations
import os

BOT_NAME = os.getenv('BOT_NAME', 'Noctix')
BOT_SHORT_NAME = os.getenv('BOT_SHORT_NAME', 'VX')
OWNER_NAME = os.getenv('OWNER_NAME', 'krishn_ax')
OWNER_IDS = tuple(int(x.strip()) for x in os.getenv('OWNER_IDS', ',').split(',') if x.strip().isdigit())
SUPPORT_SERVER = os.getenv('SUPPORT_SERVER', 'https://discord.gg/mGfq3fK3pD')
THEME_COLOR = int(os.getenv('THEME_COLOR', '0x5865F2'), 16)

# Backwards-compatible aliases used by the existing codebase.
BRAND_NAME = BOT_NAME
BotName = BOT_NAME
NAME = BOT_NAME
OWNER_IDS_LIST = list(OWNER_IDS)
