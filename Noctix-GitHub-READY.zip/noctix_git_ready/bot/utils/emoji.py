"""Noctix — unified emoji catalog.

The original emoji package has been replaced by the four supplied Noctix packs.
Custom emojis start with <name:0> placeholders and are resolved by EmojiSync after
they are uploaded to the Discord Developer Portal/application emojis.
"""

# Custom emojis are resolved at startup by EmojiSync.  The resolver reads a
# small runtime cache written by sync_emojis.py, so deleted/recreated Portal
# emojis are repaired without baking stale Discord IDs into the source tree.
import json
from pathlib import Path
import re

_CACHE_PATH = Path(__file__).resolve().parents[1] / "data" / "emoji_ids.json"
try:
    _EMOJI_CACHE = json.loads(_CACHE_PATH.read_text(encoding="utf-8"))
    if not isinstance(_EMOJI_CACHE, dict):
        _EMOJI_CACHE = {}
except (OSError, json.JSONDecodeError):
    _EMOJI_CACHE = {}

def _emoji(value: str, fallback: str = "✨") -> str:
    try:
        match = re.fullmatch(r"<a?:([A-Za-z0-9_]+):\d+>", value or "")
        if match and match.group(1).startswith(("noctix_", "vex_")):
            return str(_EMOJI_CACHE.get(match.group(1), fallback))
        if value and value.rsplit(":", 1)[-1].rstrip(">") != "0":
            return value
    except Exception:
        pass
    return fallback

BOOST = _emoji("<:noctix_gold_22729_nitro_gold:0>")

BUG_HUNTER = _emoji("<:noctix_gold_9765_badge_bugbuster:0>")

BUG_HUNTER_LVL2 = _emoji("✨")

CAST = _emoji("✨")

CERTIFIED_MODERATOR = _emoji("<:noctix_pink_35291_server_booster:0>")

CHANNEL = _emoji("✨")

CODEBASE = _emoji("✨")

CODED = _emoji("<:noctix_gold_5055_golden_diamond:0>")

CROSS = '❌'

CROSS_ALT = '❌'

CUTE_CUTE_CUTE = '✨'

DELETE = _emoji("✨")

DELETE_ALT1 = _emoji("✨")

DENIED = _emoji("<:noctix_black_5577_warning:0>")

DISABLE = _emoji("<:noctix_black_9265_admin_black:0>")

DND = '✨'

EARLY_SUPPORTER = '✨'

ENABLE = _emoji("✨")

ERROR = _emoji("<:noctix_black_5577_warning:0>")

FORWARD = _emoji("✨")


HANDSHAKE = '🤝'

HAPPY_PANDA = '✨'

HEADMOD = '🔰'

HEART3 = '❤️'

HEART_EM = '❤️'

HEERIYE = '✨'

HOME = _emoji("✨")

HYPESQUAD_BRILLIANCE = '✨'

ICONLOAD = '✨'

ICONS_CHANNEL = '📁'

ICONS_MUSIC = '🎵'

ICONS_PAUSE = '✨'

ICONS_PLUS = '✨'

ICONS_WARNING = '⚠️'

ICONS_WARNING_ALT1 = '⚠️'

ICON_BROWSER = _emoji("✨")

IDLE = _emoji("✨")

INDEX = '✨'

INFO = _emoji("✨")

KING = _emoji("<:noctix_gold_8145_gold_crown:0>")

LEVEL_UP = _emoji("<:noctix_pink_35291_server_booster:0>")

LOCK = '🔒'

MANAGER = _emoji("<:noctix_pink_35291_server_booster:0>")

MENTION = _emoji("✨")

MESSAGE = _emoji("✨")

ML_CROSS = '❌'

MUSIC = _emoji("✨")

MUSICSTOP_ICONS = '🎵'

MUTE = _emoji("✨")

NEW = '✨'

NEXT = _emoji("✨")

NEXT_ALT1 = '➡️'

OFFLINE = _emoji("<:noctix_elegant_13512_1kmembers_i:0>")

PARTNER_BADGE = '✨'

PC = _emoji("✨")

PIN = _emoji("✨")

PREVIOUS = _emoji("✨")

RED_BUTTON = '🔴'

RED_PIN = _emoji("✨")

REWIND = _emoji("✨")

REWIND_ALT1 = '⬅️'

SEED = _emoji("✨")

SHUFFLE = '✨'

SKIP = _emoji("✨")

STAR = _emoji("✨")

SWORD = '⚔️'

SYSTEM = '✨'

THUNDER = '✨'

TICK = _emoji("✨")

TICKET = _emoji("<:noctix_pink_35291_server_booster:0>")

TICK_ALT = _emoji("✨")

TIME = _emoji("✨")

TIMER = _emoji("✨")

UNLOCK = '🔓'

UPTIME = '🕒'

U_ADMIN = '🛡️'

WARNING = _emoji("✨")

WARNING_ALT = _emoji("✨")

WIFI = '✨'


ZARROW = _emoji("✨")

ZBACK = _emoji("✨")

ZBAN = _emoji("<:noctix_pink_35291_server_booster:0>")

ZBOT = _emoji("<:noctix_elegant_13512_1kmembers_i:0>")

ZCIRCLE = '⭕'

ZCIRCLE_ALT1 = '⭕'

ZCLOUD = '☁️'

ZCOUNTING = _emoji("✨")

ZCROSS = '❌'

ZDIL = '✨'

ZHUMAN = _emoji("<:noctix_elegant_13512_1kmembers_i:0>")

ZMODULE = _emoji("✨")

ZMUSICPAUSE = '🎵'

ZPAUSE = '✨'

ZPEOPLE = _emoji("<:noctix_elegant_13512_1kmembers_i:0>")

ZPLAY = '✨'

ZPLUS = '➕'

ZROCKET = _emoji("✨")

ZSAFE = _emoji("✨")

ZSETTINGS = _emoji("✨")

ZTADA = _emoji("✨")

ZTICK = '✅'

ZUNMUTE = _emoji("✨")

ZWARNING = _emoji("✨")

ZWRENCH = _emoji("✨")

VeXCONNECTION = '✨'

VeXHAMMER = '🔨'

VeXLINKS = '✨'

VeXSYS = '✨'

VeX_CODE = _emoji("✨")

VeX_COMMAND = _emoji("✨")

VeX_GLOBAL = _emoji("✨")

VeX_OWNER = _emoji("✨")

VeX_SEARCH = _emoji("✨")

ACTIVE_DEVELOPER = _emoji("<:noctix_pink_35291_server_booster:0>")

ARROWRED = _emoji("✨")

BLACKCROWN = _emoji("<:noctix_elegant_13512_1kmembers_i:0>")

BLOBPART = '✨'

BOOSTS = _emoji("<:noctix_gold_22729_nitro_gold:0>")

EARLY_VERIFIED_BOT_DEV = '🤖'

EMOTE = '✨'

GIFD = '✨'

GIFN = '✨'

HYPESQUAD_BALANCE = '✨'

HYPESQUAD_BRAVERY = '✨'

HYPESQUAD_EVENTS = '✨'

KING_ALT1 = '👑'

LOADING = '⏳'

LOADINGRED = '⏳'

LOADING_ALT1 = '✨'

MAX__A = '✨'

MENTION_ALT1 = '✨'

MINGLE = '✨'

MOBILE = '📱'

MUSIC_ALT1 = '🎵'

NITRO_BOOST = _emoji("<:noctix_gold_22729_nitro_gold:0>")

ONLINE = _emoji("✨")

PREMIUM = _emoji("<:noctix_pink_35291_server_booster:0>")

RACECAR64 = '✨'

REDDOT = _emoji("<:noctix_elegant_13512_1kmembers_i:0>")

REDHEART = '❤️'

REDRULESBOOK = _emoji("<:noctix_pink_35291_server_booster:0>")

SG_RD = '✨'

STAFF = _emoji("✨")

STAR_ALT1 = '⭐'

STAR_ALT2 = '⭐'

TADAA = '✨'

TIMER_ALT1 = '🕒'

_37496ALERT = '⚠️'

DISCORD_BADGE_EMOJIS = {'staff': STAFF, 'partner': PARTNER_BADGE, 'hypesquad': HYPESQUAD_BRILLIANCE, 'hypesquad_bravery': HYPESQUAD_BRAVERY, 'hypesquad_brilliance': HYPESQUAD_BRILLIANCE, 'hypesquad_balance': HYPESQUAD_BALANCE, 'bug_hunter': BUG_HUNTER, 'bug_hunter_level_2': BUG_HUNTER_LVL2, 'early_supporter': EARLY_SUPPORTER, 'early_verified_bot_developer': EARLY_VERIFIED_BOT_DEV, 'certified_moderator': CERTIFIED_MODERATOR, 'active_developer': ACTIVE_DEVELOPER, 'discord_mod': CERTIFIED_MODERATOR}

ARROW_DOWN = '⬇️'

ARROW_LEFT = '⬅️'

ARROW_RIGHT = '➡️'

ARROW_UP = '⬆️'

BLOCK = '🚫'

BUBBLE_TEA = '🧋'

CELEBRATE = '🎉'

CHERRIES = '🍒'

CLOCK = _emoji("✨")

COOKIE = '🍪'

CURSOR = '🖱️'

DIZZY = '🥴'

ERROR_UNICODE = '❌'

GAME_CONTROLLER = _emoji("✨")

HEARTS = '💕'


LAUGH1 = '😂'

LAUGH2 = '🤣'

LAUGH3 = '😆'

LOCK_UNICODE = '🔒'

MONEY = _emoji("✨")

MOON = '🌙'

NOTE = '📝'

PAPER = '📄'

PEACH = '🍑'

REFRESH = '🔄'

ROCK = '🪨'

SCISSORS = '✂'

SHOCKED = '😳'

SPARKLE = '✨'

STAR_UNICODE = '⭐'

STOP_BUTTON = '⏹️'

SUCCESS = _emoji("✨")

TARGET = '🎯'

TONGUE_OUT = '😜'

UPSIDE_DOWN = '🙃'

WARNING_UNICODE = '⚠️'

GAME_BUTTONS = {'up': ARROW_UP, 'down': ARROW_DOWN, 'left': ARROW_LEFT, 'right': ARROW_RIGHT, 'stop': STOP_BUTTON, 'target': '🎯'}

ACTION_EMOJIS = {'success': SUCCESS, 'error': ERROR_UNICODE, 'warning': WARNING_UNICODE, 'clock': CLOCK, 'refresh': REFRESH}

RPS_CHOICES = {'rock': ROCK, 'scissors': SCISSORS, 'paper': PAPER}

BUTTON_EMOJIS = {'note': NOTE, 'privacy': LOCK_UNICODE, 'claim': STAR_UNICODE, 'untrust': ERROR_UNICODE, 'block': BLOCK, 'target': '🎯', 'edit': '✏️'}

REACTION_TEST_EMOJIS = [COOKIE, CELEBRATE, BUBBLE_TEA, CHERRIES, PEACH, MONEY, MOON, HEARTS]

FUN_EMOJIS = [LAUGH1, LAUGH2, LAUGH3, SHOCKED, DIZZY, UPSIDE_DOWN, TONGUE_OUT]


MODERATION_EMOJIS = {'warn': WARNING, 'mute': MUTE, 'ban': SWORD, 'kick': SWORD, 'lock': LOCK}

TICKET_EMOJIS = {'ticket': TICKET, 'close': ERROR, 'open': SUCCESS, 'pin': PIN}

LEVEL_EMOJIS = {'level_up': LEVEL_UP, 'sparkle': SPARKLE, 'achievement': STAR}

UTILITY_EMOJIS = {'music': MUSIC, 'system': SYSTEM, 'new': NEW, 'message': MESSAGE, 'wifi': WIFI, 'cast': CAST}

CHECKMARK = TICK

CROSS_MARK = CROSS

CHECK = SUCCESS

FAIL = ERROR

OK = SUCCESS

NOT_OK = ERROR

# Backward-compatible Noctix aliases for legacy cogs.
# These aliases preserve compatibility for legacy modules after the Noctix rename.
NEXORA_OWNER = KING  # legacy alias; use NOCTIX_OWNER
NEXORA_CODE = CODEBASE
SUPPORT = MESSAGE

# ── Noctix supplied emoji packs ────────────────────────────────────────────────
# All 161 supplied assets are registered here. Commands should prefer these
# semantic groups so the UI stays consistent instead of scattering random emoji.
PACK_EMOJIS = {
    'black': {
        '9265-admin-black': '<:noctix_black_9265_admin_black:0>',
        '7884-member': '<:noctix_black_7884_member:0>',
        '8020-admin-badge-black': '<:noctix_black_8020_admin_badge_bl:0>',
        '1133-blk-verified': '<:noctix_pink_35291_server_booster:0>',
        '1999-admin-white': '<:noctix_elegant_13512_1kmembers_i:0>',
        '5109-verified-black': '<:noctix_elegant_13512_1kmembers_i:0>',
        '4524-blacksmalldot': '<:noctix_black_4524_blacksmalldot:0>',
        '5577-warning': '<:noctix_black_5577_warning:0>',
        '7232-rules': '<:noctix_pink_35291_server_booster:0>',
        '56137-blackowner-ids': '<:noctix_pink_35291_server_booster:0>',
        '4347-banhammer': '<:noctix_pink_35291_server_booster:0>',
        '1827-darkpartner': '<:noctix_elegant_13512_1kmembers_i:0>',
        '7375-gift': '<:noctix_pink_35291_server_booster:0>',
        '7188-male-icon': '<:noctix_elegant_13512_1kmembers_i:0>',
        '7472-staff-black': '<:noctix_black_7472_staff_black:0>',
        '1470-support': '<:noctix_elegant_13512_1kmembers_i:0>',
        '1701-announcement': '<:noctix_elegant_13512_1kmembers_i:0>',
        '5105-owner-black': '<:noctix_elegant_13512_1kmembers_i:0>',
        '1205-black-owner-badge': '<:noctix_elegant_13512_1kmembers_i:0>',
        '7576-admin-grey': '<:noctix_black_7576_admin_grey:0>',
        '8822-admin-badge-white-black': '<:noctix_pink_35291_server_booster:0>',
        '7512-members': '<:noctix_elegant_13512_1kmembers_i:0>',
        '94748-discord-executive-role-icon': '<:noctix_elegant_13512_1kmembers_i:0>',
        '6727-black-staff-badge': '<:noctix_black_6727_black_staff_ba:0>',
        '12560-blackarrow': '<:noctix_elegant_13512_1kmembers_i:0>',
        '7957-link': '<:noctix_black_7957_link:0>',
        '5486-partner-black': '<:noctix_black_5486_partner_black:0>',
        '7264-member-black': '<:noctix_black_7264_member_black:0>',
        '1045-bot': '<:noctix_elegant_13512_1kmembers_i:0>',
        '2529-member-white': '<:noctix_black_2529_member_white:0>',
        '83336-discord-server-manager': '<:noctix_pink_35291_server_booster:0>',
        '2611-black-dot': '<:noctix_elegant_13512_1kmembers_i:0>',
    },
    'blue': {
        '960664-clash': '<:noctix_blue_960664_clash:0>',
        '998200-shield': '<:noctix_elegant_82927_200members_:0>',
        '255998-ac': '<:noctix_blue_255998_ac:0>',
        '207084-no': '<:noctix_blue_207084_no:0>',
        '637215-no': '<:noctix_pink_35291_server_booster:0>',
        '696872-description': '<:noctix_blue_696872_description:0>',
        '329572-ban': '<:noctix_pink_35291_server_booster:0>',
        '946480-eye': '<:noctix_blue_946480_eye:0>',
        '340698-yes': '<:noctix_pink_35291_server_booster:0>',
        '830561-support': '<:noctix_pink_35291_server_booster:0>',
        '182447-lock': '<:noctix_elegant_13512_1kmembers_i:0>',
        '397842-bug': '<:noctix_pink_35291_server_booster:0>',
        '865892-vpn': '<:noctix_blue_865892_vpn:0>',
        '160505-heath': '<:noctix_elegant_13512_1kmembers_i:0>',
        '530749-calendar': '<:noctix_pink_35291_server_booster:0>',
        '567464-angry': '<:noctix_blue_567464_angry:0>',
        '946710-wave': '<:noctix_elegant_13512_1kmembers_i:0>',
        '276530-crown': '<:noctix_pink_35291_server_booster:0>',
        '197546-clock': '<:noctix_elegant_13512_1kmembers_i:0>',
        '95178-camera': '<:noctix_elegant_13512_1kmembers_i:0>',
        '716587-pin': '<:noctix_elegant_13512_1kmembers_i:0>',
        '600404-handshake': '<:noctix_blue_600404_handshake:0>',
        '646384-triangle': '<:noctix_pink_35291_server_booster:0>',
    },
    'dc': {
        '158897-crown': '<:noctix_elegant_13512_1kmembers_i:0>',
        '985872-star': '<:noctix_dc_985872_heart:0>',
        '16218-suport': '<:noctix_elegant_13512_1kmembers_i:0>',
        '16218-booster': '<:noctix_elegant_13512_1kmembers_i:0>',
        '702380-developer': '<:noctix_pink_35291_server_booster:0>',
        '494279-apoiador': '<:noctix_dc_494279_apoiador:0>',
        '950972-embaixador': '<:noctix_dc_950972_embaixador:0>',
        '592053-verified': '<:noctix_pink_35291_server_booster:0>',
        '592053-event': '<:noctix_pink_35291_server_booster:0>',
        '394661-github': '<:noctix_pink_35291_server_booster:0>',
        '918267-trophy': '<:noctix_elegant_13512_1kmembers_i:0>',
        '828044-fire': '<:noctix_dc_828044_ticket:0>',
        '828044-shield': '<:noctix_dc_828044_ticket:0>',
        '828044-ticket': '<:noctix_dc_828044_ticket:0>',
        '574809-rocket': '<:noctix_dc_574809_rocket:0>',
        '158897-bot': '<:noctix_elegant_13512_1kmembers_i:0>',
        '985872-heart': '<:noctix_dc_985872_heart:0>',
        '918267-partner': '<:noctix_elegant_13512_1kmembers_i:0>',
        '312424-paint': '<:noctix_pink_35291_server_booster:0>',
        '745701-youtube': '<:noctix_elegant_13512_1kmembers_i:0>',
        '400377-tools': '<:noctix_pink_35291_server_booster:0>',
    },
    'elegant': {
        '13163-notification-ids': '<:noctix_pink_35291_server_booster:0>',
        '42938-robux': '<:noctix_pink_35291_server_booster:0>',
        '69929-muted': '<:noctix_elegant_69929_muted:0>',
        '31830-red-loading': '<:noctix_pink_35291_server_booster:0>',
        '82927-200members-ids': '<:noctix_elegant_82927_200members_:0>',
        '13512-1kmembers-ids': '<:noctix_pink_35291_server_booster:0>',
        '72024-discord': '<:noctix_elegant_72024_discord:0>',
        '54356-staff-role-word-text': '<:noctix_pink_35291_server_booster:0>',
        '14324-admin-role-word-text': '<:noctix_pink_35291_server_booster:0>',
        '69014-server-booster': '<:noctix_elegant_69014_server_boos:0>',
        '85557-bot': '<:noctix_elegant_85557_bot:0>',
        '87233-lock-ids': '<:noctix_pink_35291_server_booster:0>',
        '32040-successfulverification-ids': '<:noctix_pink_35291_server_booster:0>',
        '74190-network-ids': '<:noctix_elegant_74190_network_ids:0>',
        '46754-home-ids': '<:noctix_elegant_46754_home_ids:0>',
        '80856-cogwheel-ids': '<:noctix_elegant_80856_cogwheel_id:0>',
        '46164-create-ticket': '<:noctix_elegant_46164_create_tick:0>',
        '30144-ticket-delete': '<:noctix_pink_35291_server_booster:0>',
        '48785-nitro-diamond-nodot-background': '<:noctix_elegant_48785_nitro_di_89:0>',
        '67822-opal-nitro-tier': '<:noctix_pink_35291_server_booster:0>',
        '31830-user-declined': '<:noctix_pink_35291_server_booster:0>',
    },
    'gold': {
        '9353-owner': '<:noctix_pink_35291_server_booster:0>',
        '4298-eventer': '<:noctix_gold_4298_eventer:0>',
        '5773-playstation-gold-trophy': '<:noctix_pink_35291_server_booster:0>',
        '4439-twitter-gold-checkmark': '<:noctix_pink_35291_server_booster:0>',
        '2177-owner': '<:noctix_gold_2177_owner:0>',
        '5362-goldmoderator': '<:noctix_pink_35291_server_booster:0>',
        '8530-owner': '<:noctix_pink_35291_server_booster:0>',
        '51096-vip': '<:noctix_gold_51096_vip:0>',
        '38955-management': '<:noctix_pink_35291_server_booster:0>',
        '6307-management': '<:noctix_pink_35291_server_booster:0>',
        '46910-na-crownowner': '<:noctix_gold_46910_na_crownowner:0>',
        '39178-na-trophytop': '<:noctix_pink_35291_server_booster:0>',
        '46137-verified': '<:noctix_pink_35291_server_booster:0>',
        '3021-trophy': '<:noctix_pink_35291_server_booster:0>',
        '7974-like': '<:noctix_gold_7974_like:0>',
        '70038-na-medaltop': '<:noctix_pink_35291_server_booster:0>',
        '4734-nitro-key': '<:noctix_pink_35291_server_booster:0>',
        '37372-owner': '<:noctix_pink_35291_server_booster:0>',
        '5256-owner': '<:noctix_gold_5256_owner:0>',
        '4562-yellow-shield': '<:noctix_gold_4562_yellow_shield:0>',
        '7609-wumpus-coin': '<:noctix_gold_7609_wumpus_coin:0>',
        '3293-valorant-gold-3': '<:noctix_pink_35291_server_booster:0>',
        '8145-gold-crown': '<:noctix_gold_8145_gold_crown:0>',
        '5055-golden-diamond': '<:noctix_gold_5055_golden_diamond:0>',
        '1115-crown-3': '<:noctix_pink_35291_server_booster:0>',
        '5022_GOLD_AWARD': '<:noctix_gold_5022_gold_award:0>',
        '9040-goldnitro': '<:noctix_gold_9040_goldnitro:0>',
        '22729-nitro-gold': '<:noctix_gold_22729_nitro_gold:0>',
        '9765-badge-bugbuster': '<:noctix_gold_9765_badge_bugbuster:0>',
        '37805-nitro-style-gold': '<:noctix_pink_35291_server_booster:0>',
        '31256-gold-nitro-tier': '<:noctix_pink_35291_server_booster:0>',
        '9455-yellowcrown': '<:noctix_gold_9455_yellowcrown:0>',
    },
    'pink': {
        '8468-moderator': '<:noctix_pink_8468_partner:0>',
        '3366-pin-pink': '<:noctix_pink_35291_server_booster:0>',
        '2864-pink-crown': '<:noctix_pink_2864_pink_crown:0>',
        '5704-verify': '<:noctix_pink_5704_verify:0>',
        '54538-booster': '<:noctix_pink_35291_server_booster:0>',
        '5971-verylightpinksmalldot': '<:noctix_pink_5971_verylightpin_cc:0>',
        '57122-modteampink': '<:noctix_pink_57122_modteampink:0>',
        '2990-pastel-booster': '<:noctix_pink_2990_pastel_booster:0>',
        '4850-staff': '<:noctix_pink_4850_staff:0>',
        '5591-rules': '<:noctix_pink_5591_rules:0>',
        '4650_pinkverify': '<:noctix_pink_4650_pinkverify:0>',
        '7305-lightpinksmalldot': '<:noctix_pink_35291_server_booster:0>',
        '6280-pink-arrow-right': '<:noctix_pink_6280_pink_arrow_righ:0>',
        '7267-staff-pink': '<:noctix_pink_7267_staff_pink:0>',
        '6850-hotpinkmodshield': '<:noctix_pink_6850_hotpinkmodshiel:0>',
        '2799-giveaways': '<:noctix_pink_2799_giveaways:0>',
        '3624-nitrobooster-icon': '<:noctix_pink_35291_server_booster:0>',
        '5618-nitro-pass-a': '<:noctix_pink_5618_nitro_pass_a:0>',
        '63972-booster': '<:noctix_pink_35291_server_booster:0>',
        '8468-partner': '<:noctix_pink_8468_partner:0>',
        '62880-announcements': '<:noctix_pink_62880_announcements:0>',
        '98773-announce-pink': '<:noctix_pink_35291_server_booster:0>',
        '7740-pinkcheckmark': '<:noctix_pink_7740_pinkcheckmark:0>',
        '4181-verify-pink': '<:noctix_pink_4181_verify_pink:0>',
        '4084-pink-verified': '<:noctix_pink_4084_pink_verified:0>',
        '83198-global-server-boosted': '<:noctix_pink_35291_server_booster:0>',
        '76061-serverbooster': '<:noctix_pink_76061_serverbooster:0>',
        '5788-booster': '<:noctix_pink_5788_booster:0>',
        '6876-cc-post': '<:noctix_pink_6876_cc_post:0>',
        '75527-twitch-vip': '<:noctix_pink_75527_twitch_vip:0>',
        '35291-server-booster3': '<:noctix_pink_35291_server_booster:0>',
        '70972-pink-nitro': '<:noctix_pink_70972_pink_nitro:0>',
    },
}

MODULE_EMOJIS = {
    'security': PACK_EMOJIS['black'],
    'utility': PACK_EMOJIS['blue'],
    'community': PACK_EMOJIS['dc'],
    'system': PACK_EMOJIS['elegant'],
    'owner': PACK_EMOJIS['gold'],
    'fun': PACK_EMOJIS['pink'],
}

def pack_emoji(pack: str, asset: str, fallback: str = '✨') -> str:
    """Return a supplied-pack emoji token with a safe Unicode fallback."""
    return _emoji(PACK_EMOJIS.get(pack, {}).get(asset, ''), fallback)

# High-signal semantic icons used by the new Noctix menus.
VEX_MENU = pack_emoji('elegant', '72024-discord', '✦')
VEX_SETTINGS = pack_emoji('elegant', '312424-paint', '⚙️')
VEX_DEVELOPER = pack_emoji('gold', '702380-developer', '🛠️')
VEX_OWNER = pack_emoji('gold', '9353-owner', '👑')
VEX_SECURITY = pack_emoji('black', '5577-warning', '🛡️')
VEX_SUCCESS = pack_emoji('blue', '340698-yes', '✅')
VEX_ERROR = pack_emoji('blue', '207084-no', '❌')
VEX_FUN = pack_emoji('pink', '2864-pink-crown', '🎀')
VEX_COMMUNITY = pack_emoji('dc', '16218-suport', '💬')

# Core UI tokens are intentionally mapped to the supplied packs so the main
# command/help/security surfaces use the new application emojis instead of
# generic Unicode where a supplied asset exists.
CROSS = pack_emoji('blue', '207084-no', '❌')
ERROR = pack_emoji('blue', '207084-no', '❌')
TICK = pack_emoji('blue', '340698-yes', '✅')
SUCCESS = TICK
WARNING = pack_emoji('black', '5577-warning', '⚠️')
WARNING_ALT = WARNING
ZWARNING = WARNING
INFO = pack_emoji('blue', '946480-eye', 'ℹ️')
ZSAFE = pack_emoji('blue', '998200-shield', '🛡️')
ZSETTINGS = pack_emoji('elegant', '80856-cogwheel-ids', '⚙️')
ARROWRED = pack_emoji('black', '12560-blackarrow', '➜')
ZROCKET = pack_emoji('dc', '574809-rocket', '🚀')
ZHUMAN = pack_emoji('black', '7188-male-icon', '👤')
ZBOT = pack_emoji('black', '1045-bot', '🤖')
KING = pack_emoji('gold', '8145-gold-crown', '👑')
LEVEL_UP = pack_emoji('gold', '3021-trophy', '🏆')
MANAGER = pack_emoji('gold', '38955-management', '🛠️')
TICKET = pack_emoji('elegant', '46164-create-ticket', '🎫')
PIN = pack_emoji('blue', '716587-pin', '📌')
LOCK = pack_emoji('blue', '182447-lock', '🔒')
DELETE = pack_emoji('elegant', '30144-ticket-delete', '🗑️')
SUPPORT = pack_emoji('blue', '830561-support', '💬')
VEX_COMMUNITY = pack_emoji('dc', '16218-suport', '💬')
VEX_SECURITY = pack_emoji('black', '998200-shield', '🛡️')
VEX_SUCCESS = pack_emoji('blue', '340698-yes', '✅')
VEX_ERROR = pack_emoji('blue', '207084-no', '❌')
