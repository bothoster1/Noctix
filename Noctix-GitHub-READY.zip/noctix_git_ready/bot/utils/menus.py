"""Small, dependency-free pagination source compatibility layer for Noctix.

The original project depended on discord-ext-menus, whose latest PyPI releases
are 1.0/1.1 and do not provide the requested >=1.3 constraint. Noctix only uses
PageSource/ListPageSource, so keeping these two primitives locally removes an
unnecessary runtime dependency and avoids installation failures.
"""
from __future__ import annotations

from typing import Any, Sequence

import discord


class PageSource:
    async def _prepare_once(self) -> None:
        return None

    def is_paginating(self) -> bool:
        return self.get_max_pages() != 1

    def get_max_pages(self) -> int | None:
        return None

    async def get_page(self, page_number: int) -> Any:
        raise NotImplementedError

    async def format_page(self, menu: Any, page: Any) -> Any:
        return page


class ListPageSource(PageSource):
    def __init__(self, entries: Sequence[Any], *, per_page: int = 12) -> None:
        if per_page <= 0:
            raise ValueError("per_page must be greater than zero")
        self.entries = list(entries)
        self.per_page = per_page

    def get_max_pages(self) -> int:
        if not self.entries:
            return 1
        return (len(self.entries) + self.per_page - 1) // self.per_page

    async def get_page(self, page_number: int) -> list[Any]:
        maximum = self.get_max_pages()
        if page_number < 0 or page_number >= maximum:
            raise IndexError("page number out of range")
        start = page_number * self.per_page
        return self.entries[start:start + self.per_page]
