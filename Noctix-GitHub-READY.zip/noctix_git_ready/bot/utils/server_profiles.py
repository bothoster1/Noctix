from __future__ import annotations

import json
from pathlib import Path
from typing import Any

BASE = Path(__file__).resolve().parents[1] / 'data'
BASE.mkdir(exist_ok=True)
PATH = BASE / 'server_profiles.json'
DEFAULT = {
    'name': 'Noctix',
    'description': 'Utility • Security • Fun',
    'color': 0x5865F2,
    'footer': 'Noctix • your server, your style',
    'icon_url': '',
}


def _load() -> dict[str, dict[str, Any]]:
    try:
        return json.loads(PATH.read_text(encoding='utf-8'))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


def _save(data: dict[str, dict[str, Any]]) -> None:
    tmp = PATH.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, indent=2), encoding='utf-8')
    tmp.replace(PATH)


def get(guild_id: int) -> dict[str, Any]:
    data = _load()
    value = {**DEFAULT, **data.get(str(guild_id), {})}
    value['color'] = int(value.get('color', DEFAULT['color']))
    return value


def update(guild_id: int, **changes: Any) -> dict[str, Any]:
    data = _load()
    current = {**DEFAULT, **data.get(str(guild_id), {})}
    current.update({k: v for k, v in changes.items() if v is not None})
    data[str(guild_id)] = current
    _save(data)
    return current


def reset(guild_id: int) -> None:
    data = _load()
    data.pop(str(guild_id), None)
    _save(data)
