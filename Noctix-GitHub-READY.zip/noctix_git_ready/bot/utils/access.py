"""Noctix runtime access control.

Owners come only from OWNER_IDS in the environment. Developers are persisted
locally and can only be changed by an owner. Guild staff/roles never grant
developer or no-prefix privileges.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

from utils.config import OWNER_IDS, DEV_IDS

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
PATH = DATA_DIR / "access.json"


def _read() -> dict:
    try:
        data = json.loads(PATH.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


def _write(data: dict) -> None:
    tmp = PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    tmp.replace(PATH)


def load_developers() -> set[int]:
    data = _read()
    stored = data.get("developers", [])
    if not isinstance(stored, list):
        stored = []
    result = {int(x) for x in stored if str(x).isdigit()}
    # Environment developers are always trusted, but are not silently written
    # into persistent storage.
    result.update(int(x) for x in DEV_IDS)
    result.difference_update(int(x) for x in OWNER_IDS)
    return result


def save_developers(ids: Iterable[int]) -> set[int]:
    clean = {int(x) for x in ids if int(x) not in set(OWNER_IDS)}
    _write({"developers": sorted(clean)})
    return clean


def is_owner(user_id: int) -> bool:
    return int(user_id) in set(OWNER_IDS)


def is_developer(user_id: int, developers: Iterable[int] | None = None) -> bool:
    pool = load_developers() if developers is None else set(developers)
    return int(user_id) in pool


def is_owner_or_developer(user_id: int, developers: Iterable[int] | None = None) -> bool:
    return is_owner(user_id) or is_developer(user_id, developers)


def is_developer_only(user_id: int, developers: Iterable[int] | None = None) -> bool:
    return is_developer(user_id, developers) and not is_owner(user_id)
