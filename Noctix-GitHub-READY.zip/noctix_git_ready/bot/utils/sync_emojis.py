"""Safe Noctix application-emoji synchronizer.

This runs before the Discord bot imports its cogs.  Missing application emojis
are uploaded from the bundled manifest and all <:name:0> placeholders in the
emoji catalog are replaced with the application's real emoji IDs.

Failure is non-fatal: the catalog has Unicode fallbacks, so Noctix can still boot.
"""
from __future__ import annotations

import asyncio
import base64
import json
import os
import re
from pathlib import Path

import aiohttp

BOT_ROOT = Path(__file__).resolve().parents[1]
EMOJI_PY_PATH = Path(__file__).resolve().parent / "emoji.py"
MANIFEST_PATH = BOT_ROOT.parent / "emojis" / "manifest.json"
CACHE_PATH = BOT_ROOT / "data" / "emoji_ids.json"


def _log(symbol: str, msg: str) -> None:
    print(f"[Noctix EmojiSync] {symbol} {msg}")


def _mime_for(path: Path) -> str:
    return {
        ".png": "image/png",
        ".gif": "image/gif",
        ".webp": "image/webp",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
    }.get(path.suffix.lower(), "application/octet-stream")


async def _request_json(session, method, url, **kwargs):
    """Retry Discord transient/rate-limit responses without crashing startup."""
    for attempt in range(5):
        try:
            async with session.request(method, url, **kwargs) as response:
                if response.status == 429:
                    try:
                        data = await response.json()
                        retry_after = float(data.get("retry_after", 1.0))
                    except Exception:
                        retry_after = 1.0
                    await asyncio.sleep(min(max(retry_after, 0.5), 30.0))
                    continue

                if 500 <= response.status < 600:
                    await asyncio.sleep(min(2 ** attempt, 10))
                    continue

                body = await response.text()
                try:
                    parsed = json.loads(body) if body else {}
                except json.JSONDecodeError:
                    parsed = body
                return response.status, parsed

        except (aiohttp.ClientError, asyncio.TimeoutError):
            if attempt == 4:
                return None, None
            await asyncio.sleep(min(2 ** attempt, 8))

    return None, None


async def _upload(session, app_id: str, name: str, path: Path):
    if not path.is_file():
        _log("!", f"missing emoji asset: {path}")
        return None

    try:
        raw = path.read_bytes()
    except OSError as exc:
        _log("!", f"cannot read {path.name}: {exc}")
        return None

    if len(raw) > 256 * 1024:
        _log("!", f"emoji asset too large: {path.name}")
        return None

    image_uri = (
        f"data:{_mime_for(path)};"
        f"base64,{base64.b64encode(raw).decode('ascii')}"
    )
    status, data = await _request_json(
        session,
        "POST",
        f"https://discord.com/api/v10/applications/{app_id}/emojis",
        json={"name": name, "image": image_uri},
    )
    if status in (200, 201) and isinstance(data, dict) and data.get("id"):
        return data
    _log("!", f"Discord rejected {name} (HTTP {status})")
    return None


async def _delete(session, app_id: str, emoji_id: str) -> bool:
    status, _ = await _request_json(
        session,
        "DELETE",
        f"https://discord.com/api/v10/applications/{app_id}/emojis/{emoji_id}",
    )
    if status in (200, 204):
        return True
    _log("!", f"could not remove stale Noctix emoji {emoji_id} (HTTP {status})")
    return False


async def run_sync(token: str) -> bool:
    """Synchronize emojis. Returns True if the catalog was changed."""
    if os.getenv("EMOJI_SYNC", "true").strip().lower() != "true":
        _log("•", "disabled by EMOJI_SYNC=false")
        return False
    if not token:
        _log("!", "TOKEN is not set; emoji sync skipped")
        return False
    if not MANIFEST_PATH.is_file():
        _log("!", "emojis/manifest.json is missing; emoji sync skipped")
        return False

    try:
        manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
        entries = manifest.get("emojis", [])
        content = EMOJI_PY_PATH.read_text(encoding="utf-8")
    except Exception as exc:
        _log("!", f"cannot load emoji catalog: {exc}")
        return False

    by_name = {str(e.get("discord_name", "")): e for e in entries}
    # Reconcile every supplied Noctix emoji on every startup. This repairs stale
    # IDs if an application emoji was deleted/recreated in the Developer Portal,
    # while still matching manually uploaded emojis by their exact name.
    catalog_names = sorted(name for name in by_name if name)
    if not catalog_names:
        _log("✓", "the emoji manifest is empty")
        return False
    headers = {
        "Authorization": f"Bot {token}",
        "Content-Type": "application/json",
        "User-Agent": "Noctix-EmojiSync/2.0",
    }
    timeout = aiohttp.ClientTimeout(total=45)

    try:
        async with aiohttp.ClientSession(headers=headers, timeout=timeout) as session:
            status, me = await _request_json(
                session, "GET", "https://discord.com/api/v10/users/@me"
            )
            if status != 200 or not isinstance(me, dict) or not me.get("id"):
                _log("!", f"Discord authentication failed (HTTP {status})")
                return False

            app_id = str(me["id"])
            status, data = await _request_json(
                session,
                "GET",
                f"https://discord.com/api/v10/applications/{app_id}/emojis",
            )
            if status != 200:
                _log("!", f"cannot read application emojis (HTTP {status})")
                return False

            app_emojis = data.get("items", []) if isinstance(data, dict) else []
            by_app_name = {str(e.get("name", "")).lower(): e for e in app_emojis}

            # Keep the application below Discord's emoji limit when upgrading
            # from older Noctix builds. Only remove names owned by our old/new
            # Noctix namespaces; unrelated application emojis are never touched.
            desired_names = {str(e.get("discord_name", "")).lower() for e in entries}
            stale = [
                e for e in app_emojis
                if str(e.get("name", "")).lower().startswith(("nx_", "vex_", "noctix_"))
                and str(e.get("name", "")).lower() not in desired_names
            ]
            if stale:
                _log("→", f"removing {len(stale)} stale Noctix application emojis")
                for stale_emoji in stale:
                    if await _delete(session, app_id, str(stale_emoji.get("id", ""))):
                        by_app_name.pop(str(stale_emoji.get("name", "")).lower(), None)
                        await asyncio.sleep(0.2)

            changed = False
            uploaded = 0
            matched = 0
            failed = 0
            cache = {}

            _log("→", f"checking {len(catalog_names)} supplied custom emojis")

            for name in catalog_names:
                entry = by_name[name]
                existing = by_app_name.get(name.lower())

                if existing is None:
                    source = BOT_ROOT.parent / str(entry["source"])
                    existing = await _upload(session, app_id, name, source)
                    if existing:
                        by_app_name[str(existing["name"]).lower()] = existing
                        uploaded += 1
                        await asyncio.sleep(0.35)

                if not existing:
                    failed += 1
                    continue

                actual_name = str(existing["name"])
                token_prefix = "a" if bool(existing.get("animated")) else ""
                cache[name] = f"<{token_prefix}:{actual_name}:{existing['id']}>"
                matched += 1

            CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
            try:
                previous = json.loads(CACHE_PATH.read_text(encoding="utf-8")) if CACHE_PATH.is_file() else {}
                if previous != cache:
                    CACHE_PATH.write_text(json.dumps(cache, indent=2, sort_keys=True), encoding="utf-8")
                    changed = True
            except (OSError, json.JSONDecodeError) as exc:
                _log("!", f"could not save emoji cache: {exc}")
                return False

            _log("✓", f"complete — matched={matched}, uploaded={uploaded}, failed={failed}")
            return changed

    except Exception as exc:
        _log("!", f"non-fatal sync error: {type(exc).__name__}: {exc}")
        return False


async def startup_sync(token: str) -> None:
    """Sync once before importing NoctixCore/cogs."""
    await run_sync(token)
