# ╔══════════════════════════════════════════════════════════════════╗
# ║                                                                  ║
# ║   ░█▀▀░█▀█░█▀▄░█▀▀░█░█   ░█▀▄░█▀▀░█░█░█▀▀                     ║
# ║   ░█░░░█░█░█░█░█▀▀░▄▀▄   ░█░█░█▀▀░▀▄▀░▀▀█                     ║
# ║   ░▀▀▀░▀▀▀░▀▀░░▀▀▀░▀░▀   ░▀▀░░▀▀▀░░▀░░▀▀▀                     ║
# ║                                                                  ║
# ║            © 2026 Noctix Team — All Rights Reserved              ║
# ║                                                                  ║
# ║   discord  ──  https://                      ║
# ║   youtube  ──  Noctix Team                   ║
# ║   github   ──  https://github.com/RayExo                        ║
# ║                                                                  ║
# ╚══════════════════════════════════════════════════════════════════╝

import os
from dotenv import load_dotenv

load_dotenv()

TOKEN      = os.environ.get("TOKEN", "").strip()
BRAND_NAME = os.environ.get("BOT_NAME", "Noctix")
NAME       = BRAND_NAME
BotName    = BRAND_NAME

server     = os.getenv("SUPPORT_SERVER", "https://discord.gg/mGfq3fK3pD").strip()
serverLink = server
ch         = os.getenv("SUPPORT_CHANNEL_URL", server).strip()

CMD_WEBHOOK_URL = os.getenv("CMD_WEBHOOK_URL")

# ── Owner / Staff IDs ─────────────────────────────────────────────────────────
# Edit OWNER_IDS in .env — comma-separated, no spaces needed.
# Example: OWNER_IDS=123456789012345678

def _parse_ids(env_key: str, defaults: list[int]) -> list[int]:
    raw = os.getenv(env_key, "").strip()
    if not raw:
        return defaults
    ids = [int(p.strip()) for p in raw.split(",") if p.strip().isdigit()]
    return ids or defaults

OWNER_IDS:     list[int] = _parse_ids("OWNER_IDS",     [1472042046884679801, 1518889511327760537])
OWNER_IDS_STR: list[str] = [str(i) for i in OWNER_IDS]

# Aliases kept for backwards compatibility with files that import these names
BOT_OWNER_IDS     = OWNER_IDS
BOT_OWNER_IDS_STR = OWNER_IDS_STR
STAFF_IDS         = OWNER_IDS
STAFF_IDS_STR     = OWNER_IDS_STR
OWNER_NAME = os.getenv("OWNER_NAME", "krishn_ax")

# Developer IDs are separate from guild staff. They are the only additional
# identities allowed to use developer-only features such as no-prefix.
# Keep this list small and trusted. Defaults to the configured bot owners.
DEV_IDS: list[int] = _parse_ids("DEV_IDS", [])
DEV_IDS_STR: list[str] = [str(i) for i in DEV_IDS]
PRIVILEGED_IDS: frozenset[int] = frozenset((*OWNER_IDS, *DEV_IDS))
