"""Noctix bot entry point when the bot directory itself is the working directory."""
from __future__ import annotations

import asyncio
import os

from dotenv import load_dotenv

load_dotenv()

async def main() -> None:
    token = os.getenv("TOKEN", "").strip()
    # Keep direct bot-directory hosting just as safe as the root launcher:
    # synchronize application emojis before importing cogs.
    try:
        from utils.sync_emojis import startup_sync
        await startup_sync(token)
    except Exception as exc:
        print(f"[VeX] Emoji startup check skipped: {type(exc).__name__}: {exc}")

    from VeXCore import main as bot_main
    await bot_main()

if __name__ == "__main__":
    asyncio.run(main())
