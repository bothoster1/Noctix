# ╔══════════════════════════════════════════════════════════════════╗
# ║                                                                  ║
# ║   ░█▀▀░█▀█░█▀▄░█▀▀░█░█   ░█▀▄░█▀▀░█░█░█▀▀                     ║
# ║   ░█░░░█░█░█░█░█▀▀░▄▀▄   ░█░█░█▀▀░▀▄▀░▀▀█                     ║
# ║   ░▀▀▀░▀▀▀░▀▀░░▀▀▀░▀░▀   ░▀▀░░▀▀▀░░▀░░▀▀▀                     ║
# ║                                                                  ║
# ║            © 2026 Noctix Team — All Rights Reserved              ║
# ║                                                                  ║
# ║   discord  ──  https://                      ║
# ║   youtube  ──  Noctix Team                   ║
# ║   github   ──  https://github.com/RayExo                        ║
# ║                                                                  ║
# ╚══════════════════════════════════════════════════════════════════╝

from __future__ import annotations
from discord.ext import commands, tasks
import discord
import aiohttp
import json
import jishaku
import asyncio
import typing
from typing import List
import aiosqlite
from utils.config import OWNER_IDS, DEV_IDS, PRIVILEGED_IDS, BotName, serverLink
from utils.access import load_developers, is_owner_or_developer
from utils import getConfig, updateConfig
from .Context import Context
from colorama import Fore, Style, init
import importlib
import inspect
import os

init(autoreset=True)

# Corrected the extensions list
extensions: List[str] = [
    "cogs"
]

class zyrox(commands.AutoShardedBot):
    def __init__(self, *arg, **kwargs):
        intents = discord.Intents.all()
        intents.presences = True
        intents.members = True
        intents.message_content = True
        # Noctix uses discord.py (not Py-Cord).  Keep the constructor limited to
        # arguments supported by discord.py; slash-command syncing is handled
        # explicitly by Noctix on_ready.
        shard_count_raw = os.getenv("SHARD_COUNT", "0").strip()
        try:
            configured_shards = int(shard_count_raw)
        except ValueError:
            configured_shards = 0

        bot_kwargs = dict(
            command_prefix=self.get_prefix,
            case_insensitive=True,
            intents=intents,
            status=discord.Status.do_not_disturb,
            strip_after_prefix=True,
            allowed_mentions=discord.AllowedMentions(
                everyone=False, replied_user=False, roles=False),
        )
        # Explicit owner IDs are optional. When omitted, discord.py can resolve
        # the application owner instead of trusting IDs from an old deployment.
        if OWNER_IDS:
            bot_kwargs["owner_ids"] = set(OWNER_IDS)
        if configured_shards > 0:
            bot_kwargs["shard_count"] = configured_shards

        super().__init__(**bot_kwargs)
        self.status_index = 0
        self.status_list = []
        self.vex_dev_ids = load_developers()
        self.no_prefix_ids: set[int] = set()

    async def setup_hook(self):
        await self.load_extensions()
        self.status_task.start()

    async def load_extensions(self):
        for extension in extensions:
            try:
                await self.load_extension(extension)
                print(Fore.GREEN + Style.BRIGHT + f"Loaded extension: {extension}")
            except Exception as e:
                print(f"{Fore.RED}{Style.BRIGHT}Failed to load extension {extension}. {e}")
        print(Fore.GREEN + Style.BRIGHT + "*" * 20)

    @tasks.loop(seconds=30)
    async def status_task(self):
        await self.wait_until_ready()
        if not self.guilds:
            return

        guild = self.guilds[0]  # Use first available guild for prefix
        try:
            config = await getConfig(guild.id)
            prefix = config.get("prefix", ">")
        except:
            prefix = ">"

        user_count = sum(g.member_count or 0 for g in self.guilds)
        guild_count = len(self.guilds)

        self.status_list = [
            (discord.ActivityType.playing, f"{prefix}help | Security in your Server"),
            (discord.ActivityType.watching, f"{user_count} users"),
            (discord.ActivityType.watching, f"{guild_count} servers"),
            (discord.ActivityType.listening, "Killing Nukers"),
            (discord.ActivityType.playing, f"Protector {BotName}"),
        ]

        current = self.status_list[self.status_index % len(self.status_list)]
        # This task only changes the activity, not the online status (dnd, idle, etc.)
        await self.change_presence(activity=discord.Activity(type=current[0], name=current[1]))
        self.status_index += 1

    async def send_raw(self, channel_id: int, content: str, **kwargs) -> typing.Optional[discord.Message]:
        await self.http.send_message(channel_id, content, **kwargs)

    async def invoke_help_command(self, ctx: Context) -> None:
        return await ctx.send_help(ctx.command)

    async def fetch_message_by_channel(self, channel: discord.TextChannel, messageID: int) -> typing.Optional[discord.Message]:
        async for msg in channel.history(limit=1, before=discord.Object(messageID + 1), after=discord.Object(messageID - 1)):
            return msg

    async def get_prefix(self, message: discord.Message):
        if message.guild:
            guild_id = message.guild.id
            data = await getConfig(guild_id)
            prefix = data["prefix"]
            # Owners/developers and explicitly granted no-prefix users may omit
            # the prefix. The grant itself can only be managed by owners/devs.
            if (message.author.id in self.vex_dev_ids
                    or message.author.id in OWNER_IDS
                    or message.author.id in self.no_prefix_ids):
                return commands.when_mentioned_or(prefix, '')(self, message)
            return commands.when_mentioned_or(prefix)(self, message)
        else:
            if (message.author.id in self.vex_dev_ids
                    or message.author.id in OWNER_IDS
                    or message.author.id in self.no_prefix_ids):
                return commands.when_mentioned_or('?','')(self, message)
            return commands.when_mentioned_or('')(self, message)

    async def on_guild_join(self, guild: discord.Guild):
        """Send a single aesthetic onboarding message and owner DM."""
        embed = discord.Embed(
            title=f"✦ {BotName} is ready",
            description=(
                f"Thanks for adding **{BotName}** to **{discord.utils.escape_markdown(guild.name)}**!\n\n"
                "Use `>help` (or your configured prefix) to explore moderation, security, utility, fun, and server tools.\n\n"
                f"🛡️ **Security:** configure Antinuke and Automod\n"
                f"⚙️ **Management:** use the server dashboard/customization tools\n"
                f"💜 **Support:** {serverLink}"
            ),
            color=0x7C3AED,
        )
        if self.user:
            embed.set_thumbnail(url=self.user.display_avatar.url)
        embed.set_footer(text=f"{BotName} • Secure • Stylish • Built for Discord")

        sent = False
        candidates = []
        if guild.system_channel:
            candidates.append(guild.system_channel)
        candidates.extend([c for c in guild.text_channels if c not in candidates])
        for channel in candidates:
            try:
                perms = channel.permissions_for(guild.me)
                if perms.send_messages and perms.embed_links:
                    await channel.send(embed=embed)
                    sent = True
                    break
            except (discord.Forbidden, discord.HTTPException):
                continue

        owner = guild.owner
        if owner:
            try:
                dm = embed.copy()
                dm.title = f"✦ Thanks for adding {BotName}!"
                dm.description = (
                    f"Your server **{discord.utils.escape_markdown(guild.name)}** is now protected by {BotName}.\n\n"
                    f"Need help? Join the support server: {serverLink}"
                )
                await owner.send(embed=dm)
            except (discord.Forbidden, discord.HTTPException):
                pass

        print(f"[VeX] Joined guild {guild.id} ({guild.name}) — onboarding_sent={sent}")

    async def on_message_edit(self, before, after):
        ctx: Context = await self.get_context(after, cls=Context)
        if before.content != after.content:
            if after.guild is None or after.author.bot:
                return
            if ctx.command is None:
                return
            if type(ctx.channel) == "public_thread":
                return
            await self.invoke(ctx)

def setup_bot():
    intents = discord.Intents.all()
    bot = zyrox(intents=intents)
    return bot
