"""VeX hosting preflight. Safe to run before starting the bot."""
import importlib.util

required = {
    "discord": "discord.py",
    "aiohttp": "aiohttp",
}
missing = [pkg for mod, pkg in required.items() if importlib.util.find_spec(mod) is None]
if missing:
    print("[VeX] Missing required packages: " + ", ".join(missing))
    print("[VeX] Run: python3 -m pip install -r requirements.txt")
    raise SystemExit(1)
print("[VeX] Required runtime packages are available.")
