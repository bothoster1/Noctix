"""Backward-compatible launcher; use main.py / Noctix.py for hosting."""
from Noctix import main
