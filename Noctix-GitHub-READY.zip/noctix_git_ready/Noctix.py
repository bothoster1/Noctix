"""Noctix production entry point with dependency bootstrap."""
from __future__ import annotations
import importlib.util
import asyncio
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REQ = ROOT / "requirements.txt"
CORE_IMPORTS = {"discord": "discord.py", "aiohttp": "aiohttp", "aiosqlite": "aiosqlite"}

def ensure_dependencies() -> None:
    missing = [pkg for module, pkg in CORE_IMPORTS.items() if importlib.util.find_spec(module) is None]
    if not missing: return
    if not REQ.is_file(): raise SystemExit("Noctix startup error: requirements.txt is missing.")
    print(f"[Noctix] Missing dependencies detected: {', '.join(missing)}")
    print("[Noctix] Installing requirements.txt automatically...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "-r", str(REQ)], cwd=str(ROOT))

ensure_dependencies()
if not os.getenv("TOKEN", "").strip():
    print("[Noctix] ERROR: TOKEN is not configured. Set TOKEN in the hosting environment.")
    raise SystemExit(2)
from start import main

if __name__ == "__main__":
    asyncio.run(main())
