# Noctix — Hosting Ready

## Bot startup

Set the host startup file/command to:

```bash
python3 Noctix.py
```

or:

```bash
python3 start.py
```

Install dependencies:

```bash
python3 -m pip install -r requirements.txt
```

## Required environment

At minimum:

```text
TOKEN=your_real_discord_bot_token
BOT_NAME=Noctix
OWNER_IDS=your_discord_user_id
DEV_IDS=your_discord_user_id
```

Do **not** paste your token into source code or commit it.

## Discord Developer Portal

Enable these Gateway Intents for the bot:

- Presence Intent
- Server Members Intent
- Message Content Intent

## Dashboard

The bot API is disabled by default so a normal bot-only host does not expose a web server.

To enable it:

```text
API_ENABLED=true
API_PORT=8000
DASHBOARD_API_KEY=<long-random-secret>
```

The Next.js dashboard is in `dashboard/`. Run it separately with:

```bash
cd dashboard
npm install
npm run build
npm start
```

Set `NEXT_PUBLIC_API_URL` to the public API URL plus `/api/v1`.

## Cloudflare

A tunnel is optional. Leave `TUNNEL_ENABLED=false` unless you have configured:

```text
CF_TUNNEL_TOKEN=
CF_TUNNEL_URL=
```

Noctix will never attempt a tunnel or install cloudflared unless explicitly enabled.

## Notes

- Noctix uses `discord.py`, not Py-Cord.
- Slash commands are synced explicitly after the bot becomes ready.
- Missing optional `jishaku` loading no longer prevents the bot from starting.
- The root launcher sets the working directory correctly so SQLite/config paths work on hosting panels.


## Noctix access control

Only `OWNER_IDS` from the hosting environment are owners.

- `dev adddev @user` — **owner only**
- `dev removedev @user` — **owner only**
- `dev listdev` — owner/developer
- `np add @user` — owner/developer
- `np remove @user` — owner/developer
- `dev addnp @user [duration]` — owner/developer
- `dev removenp @user` — owner/developer

A developer cannot promote another developer. Server roles, Manage Server, and database staff records cannot grant developer access.

### No Prefix

Yes: Noctix supports no-prefix, but **only authorized Noctix owners/developers can manage it**. A granted user can then use Noctix commands without the configured server prefix until the grant expires.

Supported durations: `10m`, `1w`, `3w`, `1m`, `3m`, `6m`, `1y`, `3y`, `lifetime`.

### Server-scoped Custom Bot Profile

Use `custombot` to style Noctix's embeds/control panel for each server:

- `custombot name <name>`
- `custombot description <text>`
- `custombot color <#hex>`
- `custombot footer <text>`
- `custombot icon <https-url>`
- `custombot preview`
- `custombot reset`

These settings require **Manage Server**. Discord does not expose a normal per-guild bot username/avatar API, so this safely customizes Noctix's server-scoped UI rather than pretending to change the global bot profile.

### Emoji system

The six supplied packs are bundled as 161 application emojis. Noctix synchronizes them before loading cogs, preserves animated GIF emoji tokens, removes only stale `nx_`/`vex_` application emojis from older Noctix builds, and falls back to Unicode if Discord's emoji API is unavailable. Emoji failure cannot prevent bot startup.

## Noctix Gateway Intents

Enable all three privileged intents in the Discord Developer Portal for Noctix:
- Presence Intent
- Server Members Intent
- Message Content Intent

The runtime explicitly enables all three (`presences`, `members`, `message_content`).

## Noctix Owners

Configured owners: `1472042046884679801` and `1518889511327760537` (krishn_ax).
Developer access is separate and can only be granted by an owner.

## Emoji setup

Set `EMOJI_SYNC=true`. Upload the supplied emoji files as **Application Emojis** in the Discord Developer Portal using the exact names in `emojis/manifest.json`. Noctix will match existing emojis by name and safely fall back to Unicode if an emoji is temporarily unavailable.

## Support

Official support server: https://discord.gg/mGfq3fK3pD
