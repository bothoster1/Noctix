# Noctix Emoji Portal Guide

Noctix uses the six supplied emoji packs as its official application-emoji set:

- `black`
- `blue`
- `dc`
- `elegant`
- `gold`
- `pink`

There are **161 supplied application emojis** in `emojis/manifest.json`.

## Manual upload

In the Discord Developer Portal, open your Noctix application and add the supplied files as **Application Emojis**.

Use the exact `discord_name` values in `emojis/manifest.json`. Noctix expects names beginning with `vex_`, for example:

- `vex_black_5577_warning`
- `vex_blue_340698_yes`
- `vex_dc_16218_suport`
- `vex_elegant_80856_cogwheel_ids`
- `vex_gold_8145_gold_crown`
- `vex_pink_2864_pink_crown`

The filename does not need to be the Discord emoji name; the **manifest name does**.

## Automatic synchronization

Keep:

```env
EMOJI_SYNC=true
```

On every startup Noctix:

1. Authenticates with the bot token.
2. Reads the application's current emoji list.
3. Matches emojis by exact name.
4. Uploads any missing supplied emoji.
5. Repairs IDs when an emoji was deleted/recreated.
6. Writes a small runtime cache to `bot/data/emoji_ids.json`.
7. Falls back to Unicode when Discord temporarily cannot provide an emoji.

The cache is intentionally not shipped in the ZIP, so a fresh deployment starts clean.

## Where the packs are used

- **Black** → security, moderation, admin, rules, warnings.
- **Blue** → status, success/error, utility, locks, search and actions.
- **DC** → community, support, events, partners, tickets and server features.
- **Elegant** → menus, settings, navigation, notifications and UI controls.
- **Gold** → owners, developers, management, achievements and premium/status surfaces.
- **Pink** → fun, social, giveaways, boosts and community accents.

Noctix keeps the emoji usage semantic instead of randomly mixing styles, so command menus remain readable and consistent.
