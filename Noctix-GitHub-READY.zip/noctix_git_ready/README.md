# Noctix — Ultimate Discord Bot

Noctix is a security-first multipurpose Discord bot built on discord.py. AI and game modules have been removed.

## Core features
- Moderation, antinuke, automod and security
- Tickets, giveaways, leveling, custom roles and reaction roles
- Music, utility, server configuration and welcome tools
- Developer controls and owner-only no-prefix management
- Per-server `custombot` branding and aesthetic control menu
- Six-pack application emoji synchronization with Unicode fallbacks
- DND presence and privileged Discord intents
- Optional FastAPI dashboard backend

## Owners
- `krishn_ax`
- `1472042046884679801`
- `1518889511327760537`

## Hosting
Use a Python 3.11/3.12 environment and start with:

```bash
python3 main.py
```

Set the Discord token only as the hosting environment variable `TOKEN`. Never put a real token in the repository or ZIP.

Recommended environment:
```env
TOKEN=your_discord_bot_token
OWNER_IDS=1472042046884679801,1518889511327760537
BOT_NAME=Noctix
SUPPORT_SERVER=https://discord.gg/mGfq3fK3pD
EMOJI_SYNC=true
API_ENABLED=false
TUNNEL_ENABLED=false
```
